# read-only parser for the engine's serialized objects (saves and configs)
import struct, zlib, sys, json
MAGIC = 0x03150044
SC = {0x11:'<Q',0x00:'<B',0x0f:'<B',0x02:'<I',0x06:'<i',0x09:'<d',0x08:'<f',0x03:'<Q',0x07:'<q',0x01:'<H',0x05:'<h',0x04:'<b'}
def al4(x): return (x+3)&~3
def crc32(s):
    if isinstance(s,str): s=s.encode()
    return (~zlib.crc32(s, 0xEDB88320 ^ 0xFFFFFFFF)) & 0xFFFFFFFF
def robj(b, o):
    z, m, n, size = struct.unpack_from('<IIII', b, o)
    assert m == MAGIC, hex(m)
    p = o + 16
    hdr = [struct.unpack_from('<II', b, p + 8*i) for i in range(n)]; p += 8*n
    noffs = struct.unpack_from('<%dI' % n, b, p); p += 4*n
    p = al4(p)
    out = {}
    for (h, t), no in zip(hdr, noffs):
        name = b[no:b.index(b'\0', no)].decode('latin1')
        ty, cnt, arr = t >> 24, (t >> 4) & 0xfffff, t & 0xf
        vals = []
        if arr and cnt == 0: p += 1
        for _ in range(cnt):
            if ty == 0x0d:
                sz = struct.unpack_from('<I', b, p + 12)[0]
                vals.append(robj(b, p)); p += 16 + sz
            elif ty == 0x0a:
                ln = struct.unpack_from('<I', b, p)[0]
                vals.append(b[p+16:p+16+ln].decode('latin1')); p += 16 + al4(ln+1)
            elif ty in SC:
                f = SC[ty]; vals.append(struct.unpack_from(f, b, p)[0]); p += struct.calcsize(f)
            else:
                raise ValueError('type %x field %s' % (ty, name))
        out[name] = vals if arr else (vals[0] if vals else None)
    return out
def sections(b, base=0):
    m, t, s, n = struct.unpack_from('<IIII', b, base)
    return {struct.unpack_from('<I', b, base+16+12*i)[0]: struct.unpack_from('<II', b, base+20+12*i) for i in range(n)}
def load(b):
    sec = sections(b)
    res = {}
    for tag, (off, size) in sec.items():
        if size >= 16 and struct.unpack_from('<I', b, off+4)[0] == MAGIC:
            res[tag] = robj(b, off)
    return res
def root(b):
    r = load(b)
    return r.get(0x65F6FA6E) or max(r.values(), key=lambda x: len(json.dumps(x)))
if __name__ == '__main__':
    b = open(sys.argv[1], 'rb').read()
    json.dump(load(b), sys.stdout, indent=1)
