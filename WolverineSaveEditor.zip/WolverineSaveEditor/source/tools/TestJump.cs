using System; using System.IO; using System.Linq; using WolverineSave;
static class TestJump
{
    static int Main(string[] a)
    {
        if (a[0] == "roundtrip")
        {
            foreach (var f in a.Skip(1)) { var b = File.ReadAllBytes(f); var o = new SaveFile(b).ToBytes(); Console.WriteLine(Path.GetFileName(f) + " identical: " + b.SequenceEqual(o)); }
            return 0;
        }
        if (a[0] == "jump")
        {
            var sf = SaveFile.Load(a[1]); var m = new SaveModel(sf);
            var sm = Story.Mission(a[3]); var so = a.Length > 4 && a[4] != "-" ? sm.Objective(a[4]) : sm.Start;
            if (so == null) { Console.WriteLine("no such objective"); return 1; }
            m.JumpTo(so, true);
            foreach (var c in m.Changes) Console.WriteLine("  " + c);
            var bytes = sf.ToBytes(); var back = new SaveModel(new SaveFile(bytes));
            File.WriteAllBytes(a[2], bytes);
            Console.WriteLine("checks: " + string.Join(" | ", back.Check(null)));
            Console.WriteLine("needs full install: " + back.NeedsFullInstall());
            return 0;
        }
        if (a[0] == "game")
        {
            var g = new GameSetup(a[1]);
            Console.WriteLine("found=" + g.Found + " installOff=" + g.InstallCheckOff + " forced=" + g.ForcedCheckpoint + " other=" + string.Join(";", g.StartOverrides));
            if (a.Length > 2 && a[2] == "fix") { g.TurnInstallCheckOff(); Console.WriteLine("after fix: installOff=" + g.InstallCheckOff); }
            if (a.Length > 2 && a[2] == "unforce") { g.RemoveForcedCheckpoint(); Console.WriteLine("after: forced=" + g.ForcedCheckpoint); }
            return 0;
        }
        if (a[0] == "all")
        {
            // every objective of every mission: jump, write, read back, sanity checks
            int n = 0, bad = 0;
            foreach (var sm in Story.Missions) foreach (var so in sm.Objectives)
            {
                if (sm.Name == "GP_LOBBY") continue;
                var sf = SaveFile.Load(a[1]); var m = new SaveModel(sf);
                try
                {
                    m.JumpTo(so, true);
                    var back = new SaveModel(new SaveFile(sf.ToBytes()));
                    var act = back.ActiveStoryMission();
                    bool ok = (sm.Hub || (act != null && act.Name == sm.Name)) && back.PrimaryObjective == so.Hash && SaveModel.IsKnownCheckpoint(back.Checkpoint)
                        && back.Objectives().Count(o => o.State == "kActive") == 1 && back.Check(null).All(c => c.Contains("past the prologue"));
                    if (!ok) { bad++; Console.WriteLine("PROBLEM " + sm.Name + " / " + so.Name + " chk=" + back.Checkpoint + " : " + string.Join(" | ", back.Check(null))); }
                }
                catch (Exception e) { bad++; Console.WriteLine("ERROR " + so.Name + ": " + e.Message); }
                n++;
            }
            Console.WriteLine(n + " jumps tried, " + bad + " problems");
            return bad;
        }
        return 2;
    }
}
