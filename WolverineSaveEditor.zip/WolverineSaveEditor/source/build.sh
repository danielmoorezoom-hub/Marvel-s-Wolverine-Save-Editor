#!/bin/bash
# Builds against the .NET Framework 4.5 reference assemblies (-sdk:4.5-api), NOT Mono's own libraries.
# Mono's libraries have extra methods (string.Split(char), TrimEnd(char), ...) that Windows' .NET Framework lacks;
# a program compiled against them starts under Mono and dies on Windows before its window appears.
set -e
cd "$(dirname "$0")"
SRC="SaveCore.cs SaveModel.cs Catalog.cs Story.cs StoryData.cs GameSetup.cs"
mcs -sdk:4.5-api -target:winexe -win32icon:app.ico -out:WolverineSaveEditor.exe -r:System.Windows.Forms -r:System.Drawing $SRC MainForm.cs
[ -f tools/TestJump.cs ] && mcs -sdk:4.5-api -out:TestJump.exe -r:System.Windows.Forms -r:System.Drawing $SRC tools/TestJump.cs
echo built
