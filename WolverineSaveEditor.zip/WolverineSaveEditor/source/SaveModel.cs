// What the editor knows about the game's save systems, on top of the raw reader/writer.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace WolverineSave
{
    public class MissionInfo
    {
        public uint Hash; public string Name; public Obj Node; public string Graph;
        public string State { get { return Node.S("MissionState"); } }
        public string Region { get { return SaveModel.RegionOf(Name); } }
    }
    public class ObjectiveInfo
    {
        public uint Hash; public string Name; public Obj Node; public string Graph;
        public string State { get { return Node.S("ObjectiveState"); } }
    }
    public class ActivityInfo
    {
        public uint Hash; public string Id; public Obj Save;
        public string State { get { return Save.S("State"); } }
    }
    public class OwnedEntry { public string Key; public string Path; public Obj Entry; }

    public class SaveModel
    {
        public readonly SaveFile File;
        public readonly Dictionary<uint, string> Names = new Dictionary<uint, string>();
        public readonly List<string> Changes = new List<string>();

        public static readonly string[] MissionStates = { "kInactive", "kAvailable", "kActive", "kCompleteFinished" };
        public static readonly string[] ObjectiveStates = { "kInactive", "kActive", "kComplete" };
        public static readonly string[] ActivityStates = { "kNotStarted", "kActive", "kFinished" };
        public const string RewardGiven = "kProgressionRewardGiven";

        public SaveModel(SaveFile f)
        {
            File = f;
            foreach (var n in Catalog.Names) AddName(n);
            foreach (var n in Catalog.Missions) AddName(n);
            foreach (var c in Catalog.Checkpoints) { AddName(c); if (c.StartsWith("CHK_")) AddName(c.Substring(4)); }
            foreach (var m in Story.Missions) { AddName(m.Name); foreach (var o in m.Objectives) AddName(o.Name); }
            foreach (var a in Activities()) AddName(a.Id);
            foreach (var r in Rewards()) AddName(r.Key);
        }
        void AddName(string n) { if (!string.IsNullOrEmpty(n)) { uint h = Hash.Crc32(n); if (!Names.ContainsKey(h)) Names[h] = n; } }
        public string NameOf(uint h) { string n; return Names.TryGetValue(h, out n) ? n : "0x" + h.ToString("x8"); }
        public static uint ParseHashKey(string key)
        {
            if (key.StartsWith("0x")) return (uint)(ulong.Parse(key.Substring(2), NumberStyles.HexNumber) & 0xFFFFFFFF);
            return uint.Parse(key);
        }
        public static string RegionOf(string name)
        {
            if (name == null) return "";
            if (name.Contains("_CAN_")) return "Canada";
            if (name.Contains("_JPN_")) return "Japan";
            if (name.Contains("_MAD_")) return "Madripoor";
            if (name.Contains("_TEL_")) return "Telambang";
            if (name.StartsWith("GP_LOBBY")) return "Menu";
            if (name.Contains("NIGHTMARE") || name.Contains("MIND_CABIN") || name.StartsWith("MindCabin") || name.StartsWith("nightmare")) return "Nightmare / Mind Cabin";
            return "";
        }

        // --------------------------------------------------------------------------- systems
        public Obj System(string saveName)
        {
            var systems = File.Root.O("Systems");
            foreach (var f in systems.Fields)
            {
                var o = (Obj)f.Value;
                if (o.S("SaveName") == saveName) { var sd = o.O("SaveData"); return sd.Has("Obj") ? sd.O("Obj") : sd; }
            }
            return null;
        }
        public Obj SaveFileData { get { return System("SaveFile"); } }
        public Obj ObjectiveSystem { get { return System("ObjectiveSystem"); } }
        public Obj SystemData { get { return ObjectiveSystem.Path("SystemData/Obj"); } }
        public Obj Hero { get { return System("HeroSystem"); } }

        void Log(string s) { Changes.Add(s); }

        // --------------------------------------------------------------------------- checkpoint
        public string Checkpoint { get { return SaveFileData.S("CurrentCheckpointName"); } }
        IEnumerable<Obj> RestorePoints()
        {
            var rs = SystemData.F("RestoreStateData");
            if (rs != null) foreach (Obj r in rs.Values) { var o = r.Path("RestoreData/Obj"); if (o != null) yield return o; }
        }
        /// <summary>Sets the checkpoint the save resumes from. Restore points that pointed at the old checkpoint follow it
        /// (all of them when everywhere is true).</summary>
        public void SetCheckpoint(string name, bool everywhere = false)
        {
            uint old = Convert.ToUInt32(SaveFileData["CurrentCheckpoint"]), now = Hash.Crc32(name);
            bool changed = name != Checkpoint || old != now;
            SaveFileData["CurrentCheckpointName"] = name;
            SaveFileData["CurrentCheckpoint"] = now;
            foreach (var r in RestorePoints())
                if (r.Has("CheckPointHash") && (everywhere || Convert.ToUInt32(r["CheckPointHash"]) == old) && Convert.ToUInt32(r["CheckPointHash"]) != now) { r["CheckPointHash"] = now; changed = true; }
            if (changed) Log("Checkpoint -> " + name);
        }
        /// <summary>The missions a checkpoint is used by: the objectives that name it, else the mission whose name it starts with.</summary>
        public static List<string> MissionsOfCheckpoint(string chk)
        {
            var res = new List<string>(); if (chk == null) return res;
            List<StoryObjective> l;
            if (Story.ByCheckpoint.TryGetValue(chk, out l)) foreach (var o in l) if (!res.Contains(o.Mission.Name)) res.Add(o.Mission.Name);
            foreach (var m in Story.Missions) if ((m.StartCheckpoint == chk || m.Available == chk) && !res.Contains(m.Name)) res.Add(m.Name);
            if (res.Count > 0) return res;
            string body = chk.StartsWith("CHK_") ? chk.Substring(4) : chk, best = null;
            foreach (var m in Catalog.Missions)
                if ((body == m || body.StartsWith(m + "_")) && (best == null || m.Length > best.Length)) best = m;
            if (best != null) res.Add(best);
            return res;
        }
        public static string MissionOfCheckpoint(string chk) { var l = MissionsOfCheckpoint(chk); return l.Count > 0 ? l[0] : null; }
        /// <summary>True when the game's level data has a checkpoint with this name.</summary>
        public static bool IsKnownCheckpoint(string chk) { return chk != null && Array.IndexOf(Catalog.Checkpoints, chk) >= 0; }
        /// <summary>True when an objective or mission start of the shipped story uses this checkpoint.</summary>
        public static bool IsStoryCheckpoint(string chk)
        {
            if (chk == null) return false;
            return Story.ByCheckpoint.ContainsKey(chk) || Story.Missions.Any(m => m.StartCheckpoint == chk || m.Available == chk);
        }

        // --------------------------------------------------------------------------- missions & objectives
        IEnumerable<Tuple<string, uint, Obj, string>> GraphNodes()
        {
            var g = ObjectiveSystem.O("GraphDataTable");
            foreach (var gf in g.Fields)
            {
                var nt = ((Obj)gf.Value).O("NodeDataTable");
                if (nt == null) continue;
                foreach (var nf in nt.Fields)
                {
                    var nd = ((Obj)nf.Value).O("NodeData");
                    if (nd == null) continue;
                    yield return Tuple.Create(gf.Name, ParseHashKey(nf.Name), nd.O("Obj"), nd.S("Type"));
                }
            }
        }
        public List<MissionInfo> Missions()
        {
            var l = new List<MissionInfo>();
            foreach (var t in GraphNodes())
                if (t.Item4 == "MissionSaveDataGame") l.Add(new MissionInfo { Graph = t.Item1, Hash = t.Item2, Node = t.Item3, Name = NameOf(t.Item2) });
            return l;
        }
        public List<ObjectiveInfo> Objectives()
        {
            var l = new List<ObjectiveInfo>();
            foreach (var t in GraphNodes())
                if (t.Item4 == "ObjectiveSaveDataGame") l.Add(new ObjectiveInfo { Graph = t.Item1, Hash = t.Item2, Node = t.Item3, Name = NameOf(t.Item2) });
            return l;
        }
        static void SetFlag(Obj node, string field, string flag, bool on)
        {
            var f = node.F(field); if (f == null) return;
            bool has = f.Values.Contains(flag);
            if (on && !has) { f.Type = FType.Str; f.Values.Add(flag); }
            if (!on && has) { f.Values.Remove(flag); if (f.Values.Count == 0) f.Type = (FType)0x13; }
        }
        static void Put(Obj o, string field, object value) { if (o.Has(field)) o[field] = value; }
        /// <summary>Writes a mission node the way the game leaves it in each state.</summary>
        void ApplyMissionState(MissionInfo m, string state, uint primaryObjective, uint segment, bool resetCount)
        {
            var n = m.Node; bool was = m.State == "kCompleteFinished";
            n["MissionState"] = state;
            Put(n, "RestoreLayerIndex", state == "kActive" ? 0 : -1);
            Put(n, "PrimaryObjective", state == "kActive" ? primaryObjective : 0u);
            Put(n, "DevstatsSegmentId", state == "kActive" ? segment : 0u);
            if (state == "kActive") Put(n, "CurrentAbandonAction", "kDefault");
            else if (!(state == "kCompleteFinished" && was)) Put(n, "CurrentAbandonAction", "kDeactivateMission");
            if (state == "kCompleteFinished") { if (Convert.ToUInt32(n["CompletedCount"]) == 0) n["CompletedCount"] = 1u; }
            else if (resetCount && (state == "kInactive" || state == "kAvailable")) { n["CompletedCount"] = 0u; SetFlag(n, "MissionFlagsGame", RewardGiven, false); }
        }
        uint Segment(string forMission)
        {
            foreach (var m in Missions()) if (m.State == "kActive" && m.Node.Has("DevstatsSegmentId") && Convert.ToUInt32(m.Node["DevstatsSegmentId"]) != 0) return Convert.ToUInt32(m.Node["DevstatsSegmentId"]);
            return Hash.Crc32("save_editor_segment_" + forMission) | 1u;
        }
        public void SetMissionState(MissionInfo m, string state, bool markRewardsGiven)
        {
            if (m.State == state) return;
            uint keep = m.Node.Has("PrimaryObjective") ? Convert.ToUInt32(m.Node["PrimaryObjective"]) : 0;
            ApplyMissionState(m, state, keep, state == "kActive" ? Segment(m.Name) : 0, true);
            if (state == "kCompleteFinished" && markRewardsGiven) SetFlag(m.Node, "MissionFlagsGame", RewardGiven, true);
            Log("Mission " + m.Name + " -> " + state);
        }
        public void SetObjectiveState(ObjectiveInfo o, string state)
        {
            if (o.State == state) return;
            o.Node["ObjectiveState"] = state;
            if (state == "kComplete") SetFlag(o.Node, "ObjectiveFlagsGame", RewardGiven, true);
            Log("Objective " + o.Name + " -> " + state);
        }
        public uint PrimaryMission { get { return Convert.ToUInt32(SystemData.O("PrimaryObjective")["MissionHash"]); } }
        public uint PrimaryObjective { get { return Convert.ToUInt32(SystemData.O("PrimaryObjective")["ObjectiveHash"]); } }
        public void SetPrimary(uint mission, uint objective)
        {
            var p = SystemData.O("PrimaryObjective");
            if (Convert.ToUInt32(p["MissionHash"]) == mission && Convert.ToUInt32(p["ObjectiveHash"]) == objective) return;
            p["MissionHash"] = mission; p["ObjectiveHash"] = objective;
            if (SystemData.Has("PlayerSelectedMission")) SystemData["PlayerSelectedMission"] = mission;
            foreach (var m in Missions()) if (m.Hash == mission && m.Node.Has("PrimaryObjective")) m.Node["PrimaryObjective"] = objective;
            Log("Primary objective -> " + NameOf(mission) + " / " + (objective == 0 ? "(none)" : NameOf(objective)));
        }
        public string Campaign { get { return SystemData.S("CurrentCampaign"); } }

        // --------------------------------------------------------------------------- activities
        public List<ActivityInfo> Activities()
        {
            var l = new List<ActivityInfo>();
            var acts = System("ActivitySystem").O("Activities");
            foreach (var f in acts.Fields)
            {
                var o = (Obj)f.Value;
                l.Add(new ActivityInfo { Hash = ParseHashKey(f.Name), Id = o.S("ActivityId"), Save = o.Path("ActivitySave/Obj") });
            }
            return l;
        }
        public void SetActivity(ActivityInfo a, string state, bool? visible)
        {
            bool changed = false;
            if (state != null && a.State != state) { a.Save["State"] = state; changed = true; }
            if (visible.HasValue && Convert.ToByte(a.Save["Visible"]) != (visible.Value ? 1 : 0)) { a.Save["Visible"] = (byte)(visible.Value ? 1 : 0); changed = true; }
            if (changed) Log("Activity " + a.Id + " -> " + a.State + (Convert.ToByte(a.Save["Visible"]) != 0 ? ", visible" : ""));
        }

        // --------------------------------------------------------------------------- synced states (character, loadout)
        IEnumerable<Obj> SyncedStateTables()
        {
            // the current state first: it is what the drop-downs show; restore points follow
            var sd = SystemData;
            var cur = sd.Path("CurrentStatesRestorePoint/SyncedStateTable"); if (cur != null) yield return cur;
            var rs = sd.F("RestoreStateData");
            if (rs != null) foreach (Obj r in rs.Values) { var t = r.Path("RestoreData/Obj/SyncStates/SyncedStateTable"); if (t != null) yield return t; }
        }
        IEnumerable<Obj> SyncedStates(string type)
        {
            foreach (var t in SyncedStateTables())
                foreach (var f in t.Fields)
                {
                    var ss = ((Obj)f.Value).O("SyncedState");
                    if (ss != null && ss.S("Type") == type) yield return ss.O("Obj");
                }
        }
        string FirstValue(string type, string field) { foreach (var o in SyncedStates(type)) return o.S(field); return null; }
        void SetAll(string type, string field, string value, string what)
        {
            bool any = false;
            foreach (var o in SyncedStates(type)) if (o.S(field) != value) { o[field] = value; any = true; }
            if (any) Log(what + " -> " + value);
        }
        public string Character { get { return FirstValue("ObjectiveSyncedStateCharacterSwap", "HeroCharacter"); } set { SetAll("ObjectiveSyncedStateCharacterSwap", "HeroCharacter", value, "Character"); } }
        public string Loadout { get { return FirstValue("ObjectiveSyncedStateDebugLoadout", "LoadoutConfig"); } set { SetAll("ObjectiveSyncedStateDebugLoadout", "LoadoutConfig", value, "Mission loadout"); } }
        public string NgPlusLoadout { get { return FirstValue("ObjectiveSyncedStateDebugLoadoutNewGamePlus", "LoadoutConfig"); } }
        public List<KeyValuePair<string, string>> WorldStates()
        {
            var l = new List<KeyValuePair<string, string>>(); var seen = new HashSet<string>();
            foreach (var o in SyncedStates("ObjectiveSyncedStateWorldState"))
            {
                var e = o.Path("WorldState/StateId/Dynamic_Enum_Value_Type");
                if (e == null) continue;
                string asset = e.S("EnumAsset");
                if (asset != null && seen.Add(asset)) l.Add(new KeyValuePair<string, string>(asset, e.S("EnumValue")));
            }
            return l;
        }

        // --------------------------------------------------------------------------- gear
        public static string Pretty(string configPath)
        {
            if (configPath == null) return "";
            string n = configPath.Replace('\\', '/');
            n = n.Substring(n.LastIndexOf('/') + 1);
            if (n.EndsWith(".config", StringComparison.OrdinalIgnoreCase)) n = n.Substring(0, n.Length - 7);
            foreach (var pre in new[] { "suit_", "skill_", "tactic_", "technique_", "inv_currency_", "slot_" })
                if (n.StartsWith(pre, StringComparison.OrdinalIgnoreCase)) { n = n.Substring(pre.Length); break; }
            foreach (var suf in new[] { "_part_item", "_item" })
                if (n.EndsWith(suf, StringComparison.OrdinalIgnoreCase)) { n = n.Substring(0, n.Length - suf.Length); break; }
            n = n.Replace('_', ' ');
            return CultureInfo.InvariantCulture.TextInfo.ToTitleCase(n.ToLowerInvariant());
        }
        public static string PartCategory(string path)
        {
            string p = path.ToLowerInvariant();
            if (p.Contains("claw")) return "Claws";
            if (p.Contains("hat_")) return "Hat";
            return "Suit";
        }
        public static string Key(string configPath) { return "0x" + Hash.AssetId(configPath).ToString("x16"); }

        Obj Mgr(string name) { return Hero.O(name); }
        public List<OwnedEntry> Owned(string manager, string collection, string pathField)
        {
            var l = new List<OwnedEntry>();
            var c = Mgr(manager).O(collection);
            foreach (var f in c.Fields) { var o = (Obj)f.Value; l.Add(new OwnedEntry { Key = f.Name, Path = o.S(pathField), Entry = o }); }
            return l;
        }
        public List<OwnedEntry> Parts() { return Owned("SuitManager", "Parts", "PartItem"); }
        public List<OwnedEntry> Skills() { return Owned("UpgradeGraphManager", "Upgrades", "Item"); }
        public List<OwnedEntry> Tactics() { return Owned("TacticsManager", "Tactics", "TacticItem"); }
        public List<OwnedEntry> Techniques() { return Owned("TechniqueManager", "Techniques", "TechniqueItem"); }
        public List<OwnedEntry> PartSlots() { return Owned("SuitManager", "PartSlots", "PartSlotItem"); }

        static Field Str(string n, string v) { var f = new Field(n, FType.Str, false); f.Values.Add(v); return f; }
        static Field B(string n, byte v) { var f = new Field(n, FType.Bool, false); f.Values.Add(v); return f; }
        static Field D(string n, double v) { var f = new Field(n, FType.F64, false); f.Values.Add(v); return f; }
        static Field F(string n, float v) { var f = new Field(n, FType.F32, false); f.Values.Add(v); return f; }
        static Field U(string n, uint v) { var f = new Field(n, FType.U32, false); f.Values.Add(v); return f; }
        static Field I(string n, int v) { var f = new Field(n, FType.I32, false); f.Values.Add(v); return f; }
        static Field O(string n, Obj v) { var f = new Field(n, FType.Obj, false); f.Values.Add(v); return f; }
        static Obj TimeBlock()
        {
            var o = new Obj();
            foreach (var n in new[] { "cine_time", "blank_screen_time", "menu_time", "afk_time", "active_time" }) o.Fields.Add(D(n, 0.0));
            return o;
        }
        Obj NewEntry(string kind, string path)
        {
            var o = new Obj();
            switch (kind)
            {
                case "part":
                    o.Fields.Add(Str("PartItem", path)); o.Fields.Add(B("Viewed", 0)); o.Fields.Add(B("Introed", 0));
                    o.Fields.Add(B("ScriptedRequirementMet", 0)); o.Fields.Add(D("TimeSinceAcquire", 0.0)); o.Fields.Add(B("ShownInHUDRwd", 0)); break;
                case "skill":
                    o.Fields.Add(Str("Item", path)); o.Fields.Add(B("Viewed", 0)); o.Fields.Add(B("Introed", 0));
                    o.Fields.Add(B("ScriptedRequirementMet", 0)); o.Fields.Add(D("TimeSincePurchase", 0.0)); o.Fields.Add(B("ShownInHUDRwd", 0)); break;
                case "tactic":
                    o.Fields.Add(Str("TacticItem", path)); o.Fields.Add(U("DevstatsEquipSegmentIdHash", 0)); o.Fields.Add(B("Viewed", 0));
                    o.Fields.Add(B("ShownInHUDRwd", 0)); o.Fields.Add(B("Introed", 0)); o.Fields.Add(B("ScriptedRequirementMet", 0)); o.Fields.Add(B("Equipped", 0));
                    o.Fields.Add(O("TotalTimeOwned", TimeBlock())); o.Fields.Add(O("TotalTimeEquipped", TimeBlock())); break;
                case "technique":
                    o.Fields.Add(Str("TechniqueItem", path)); o.Fields.Add(B("Viewed", 0)); o.Fields.Add(B("Introed", 0));
                    o.Fields.Add(B("ScriptedRequirementMet", 0)); o.Fields.Add(D("TimeSincePurchase", 0.0)); o.Fields.Add(B("ShownInHUDRwd", 0));
                    o.Fields.Add(F("CooldownAtLastObjectiveStart", -1.0f)); break;
            }
            return o;
        }
        static readonly Dictionary<string, string[]> Where = new Dictionary<string, string[]> {
            { "part", new[] { "SuitManager", "Parts" } }, { "skill", new[] { "UpgradeGraphManager", "Upgrades" } },
            { "tactic", new[] { "TacticsManager", "Tactics" } }, { "technique", new[] { "TechniqueManager", "Techniques" } } };

        public bool Owns(string kind, string path)
        {
            var c = Mgr(Where[kind][0]).O(Where[kind][1]);
            return c.F(Key(path)) != null;
        }
        public void SetOwned(string kind, string path, bool own)
        {
            var c = Mgr(Where[kind][0]).O(Where[kind][1]);
            string key = Key(path);
            var existing = c.F(key);
            if (own && existing == null)
            {
                var f = new Field(key, FType.Obj, false); f.Values.Add(NewEntry(kind, path)); c.Fields.Add(f);
                SetInventory(path, 1, false);
                Log("Unlocked " + kind + " " + Pretty(path));
            }
            else if (!own && existing != null)
            {
                if (kind == "part") foreach (var s in PartSlots()) if (string.Equals(s.Entry.S("EquippedPartItem"), path, StringComparison.OrdinalIgnoreCase)) return; // never remove what is worn
                c.Fields.Remove(existing);
                RemoveInventory(path);
                Log("Removed " + kind + " " + Pretty(path));
            }
        }
        public void Equip(OwnedEntry slot, string partPath)
        {
            if (string.Equals(slot.Entry.S("EquippedPartItem"), partPath, StringComparison.OrdinalIgnoreCase)) return;
            if (!Owns("part", partPath)) SetOwned("part", partPath, true);
            slot.Entry["EquippedPartItem"] = partPath;
            Log("Equipped " + Pretty(partPath) + " (" + Pretty(slot.Path) + ")");
        }
        public void SetTacticEquipped(OwnedEntry t, bool on)
        {
            if ((Convert.ToByte(t.Entry["Equipped"]) != 0) == on) return;
            t.Entry["Equipped"] = (byte)(on ? 1 : 0);
            Log((on ? "Equipped tactic " : "Unequipped tactic ") + Pretty(t.Path));
        }

        // inventory: every owned config is also an item with a count
        Field InventoryItems { get { return Mgr("InventoryManager").O("OwnedInventorySave").F("Items"); } }
        public Obj FindItem(string path)
        {
            string id = "0x" + Hash.AssetId(path).ToString("x16");
            foreach (Obj it in InventoryItems.Values) if (string.Equals(it.S("ItemId"), id, StringComparison.OrdinalIgnoreCase)) return it;
            return null;
        }
        public void SetInventory(string path, int count, bool log = true)
        {
            var it = FindItem(path);
            if (it == null)
            {
                it = new Obj();
                it.Fields.Add(Str("ItemPath", "")); it.Fields.Add(Str("ItemId", "0x" + Hash.AssetId(path).ToString("x16"))); it.Fields.Add(I("ItemCount", count));
                var f = InventoryItems; f.Type = FType.Obj; f.Values.Add(it);
            }
            else if (Convert.ToInt32(it["ItemCount"]) == count) return;
            else it["ItemCount"] = count;
            if (log) Log("Item " + Pretty(path) + " count -> " + count);
        }
        void RemoveInventory(string path)
        {
            var it = FindItem(path); if (it == null) return;
            InventoryItems.Values.Remove(it);
            if (InventoryItems.Values.Count == 0) InventoryItems.Type = (FType)0x13;
        }
        public List<Obj> LevelTracks()
        {
            var l = new List<Obj>(); var t = Mgr("LevelManager").O("LevelTracks");
            foreach (var f in t.Fields) l.Add((Obj)f.Value);
            return l;
        }

        // --------------------------------------------------------------------------- unlock lists
        public List<KeyValuePair<string, Obj>> Rewards()
        {
            var l = new List<KeyValuePair<string, Obj>>();
            var sys = System("ProgressionRewardSystem"); if (sys == null) return l;
            foreach (var f in sys.O("Rewards").Fields)
            {
                var o = (Obj)f.Value;
                l.Add(new KeyValuePair<string, Obj>(o.S("SaveName"), o.Path("Data/Obj")));
            }
            return l;
        }
        public List<KeyValuePair<uint, Obj>> NightmareChallenges()
        {
            var l = new List<KeyValuePair<uint, Obj>>();
            var sys = System("NightmareModeSystem"); if (sys == null) return l;
            foreach (var f in sys.Path("ArenaSaveData/ChallengeSaveData").Fields) l.Add(new KeyValuePair<uint, Obj>(ParseHashKey(f.Name), (Obj)f.Value));
            return l;
        }
        public List<Tuple<uint, uint, Obj>> Collectibles()
        {
            var l = new List<Tuple<uint, uint, Obj>>();
            var sys = System("CollectibleSystemGame"); if (sys == null) return l;
            foreach (var tf in sys.O("TypeSaveData").Fields)
            {
                var inst = ((Obj)tf.Value).O("InstanceSaveData"); if (inst == null) continue;
                foreach (var f in inst.Fields) l.Add(Tuple.Create(ParseHashKey(tf.Name), ParseHashKey(f.Name), (Obj)f.Value));
            }
            return l;
        }
        public List<Obj> GalleryEntries()
        {
            var l = new List<Obj>(); var sys = System("PauseSaveSystem"); if (sys == null) return l;
            foreach (var f in sys.O("GalleryEntriesByIDHash").Fields) l.Add((Obj)f.Value);
            return l;
        }
        public void SetFieldLogged(Obj o, string field, object value, string what)
        {
            var f = o.F(field); if (f == null) return;
            object cur = f.Value;
            object nv = Convert.ChangeType(value, cur.GetType(), CultureInfo.InvariantCulture);
            if (Equals(cur, nv)) return;
            f.Value = nv; Log(what + " " + field + " -> " + nv);
        }

        // --------------------------------------------------------------------------- overall progress
        public float GamePercent { get { return Convert.ToSingle(SaveFileData["GamePercent"]); } }   // 0..1
        public void SetGamePercent(float fraction)
        {
            fraction = Math.Max(0f, Math.Min(1f, fraction));
            if (Math.Abs(GamePercent - fraction) < 0.00001f) return;
            SaveFileData["GamePercent"] = fraction; Log("Game completion -> " + Math.Round(fraction * 100) + "%");
        }
        public bool NewGamePlusUnlocked
        {
            get { return SaveFileData.Has("NewGamePlusUnlocked") && Convert.ToByte(SaveFileData["NewGamePlusUnlocked"]) != 0; }
            set { if (SaveFileData.Has("NewGamePlusUnlocked") && NewGamePlusUnlocked != value) { SaveFileData["NewGamePlusUnlocked"] = (byte)(value ? 1 : 0); Log("New Game+ unlocked -> " + (value ? "yes" : "no")); } }
        }
        /// <summary>The game keeps a count of unlocked nightmare challenges next to the list; keep the two in step.</summary>
        public void SyncNightmareCounts()
        {
            var sys = System("NightmareModeSystem"); if (sys == null) return;
            var arena = sys.O("ArenaSaveData"); if (arena == null) return;
            int unlocked = 0, viewed = 0;
            foreach (var c in NightmareChallenges()) { if (c.Value.Has("Unlocked") && Convert.ToInt64(c.Value["Unlocked"]) != 0) unlocked++; if (c.Value.Has("Viewed") && Convert.ToInt64(c.Value["Viewed"]) != 0) viewed++; }
            if (arena.Has("NumChallengesUnlocked") && Convert.ToInt32(arena["NumChallengesUnlocked"]) != unlocked) { arena["NumChallengesUnlocked"] = unlocked; Log("Nightmare challenges unlocked (count) -> " + unlocked); }
            if (arena.Has("NumChallengesViewed") && Convert.ToInt32(arena["NumChallengesViewed"]) != viewed) arena["NumChallengesViewed"] = viewed;
        }

        // --------------------------------------------------------------------------- jumping to a point in the story
        Obj NodeWrap(string type, Obj data)
        {
            var nd = new Obj(); nd.Fields.Add(Str("Type", type)); nd.Fields.Add(O("Obj", data));
            var w = new Obj(); w.Fields.Add(O("NodeData", nd)); return w;
        }
        Field BuildObjectiveGraph(StoryObjective target, uint segment)
        {
            var m = target.Mission; var before = m.Before(target.Index);
            var table = new Obj();
            foreach (var o in m.Objectives)
            {
                string st = o == target ? "kActive" : before.Contains(o.Index) ? "kComplete" : "kInactive";
                var d = new Obj();
                d.Fields.Add(U("SaveHash", o.Hash)); d.Fields.Add(Str("ObjectiveState", st)); d.Fields.Add(F("ScriptObjectiveVairable", 0f));
                d.Fields.Add(U("MissionDevstatsSegmentId", st == "kInactive" ? 0u : segment));
                d.Fields.Add(U("ObjectiveDevstatsSegmentId", o == target ? (Hash.Crc32("save_editor_segment_" + o.Name) | 1u) : 0u));
                d.Fields.Add(U("AttemptCount", st == "kComplete" ? 1u : 0u));
                var flags = new Field("ObjectiveFlagsGame", st == "kComplete" ? FType.Str : (FType)0x13, true);
                if (st == "kComplete") flags.Values.Add(RewardGiven);
                d.Fields.Add(flags);
                table.Fields.Add(O(o.Hash.ToString(), NodeWrap("ObjectiveSaveDataGame", d)));
            }
            var root = new Obj(); root.Fields.Add(U("SaveHash", 2340265533u)); root.Fields.Add(B("WasStarted", 1));
            table.Fields.Add(O("2340265533", NodeWrap("RootNodeSaveDataShared", root)));
            var graph = new Obj(); graph.Fields.Add(Str("GraphAsset", m.GraphId.ToString())); graph.Fields.Add(O("NodeDataTable", table));
            return O(m.GraphKey, graph);
        }
        static bool SetIf(Obj o, string field, object value)
        {
            var f = o == null ? null : o.F(field); if (f == null) return false;
            if (Convert.ToString(f.Value, CultureInfo.InvariantCulture) == Convert.ToString(value, CultureInfo.InvariantCulture)) return false;
            f.Value = value; return true;
        }
        int ApplyStates(Obj table, Dictionary<string, ResolvedState> states)
        {
            int changed = 0;
            foreach (var kv in states)
            {
                var f = table.Fields.FirstOrDefault(x => string.Equals(x.Name, kv.Key, StringComparison.OrdinalIgnoreCase));
                var st = kv.Value.State;
                if (f == null)
                {
                    if (st.Kind != 'W') continue;   // the fixed entries (loadout, character, lighting) exist in every save
                    var like = table.Fields.FirstOrDefault(x => ((Obj)x.Value).Path("SyncedState/Obj/WorldState") != null);
                    if (like == null) continue;
                    f = new Field(kv.Key, FType.Obj, false); f.Values.Add(((Obj)like.Value).Clone()); table.Fields.Add(f);
                }
                var o = ((Obj)f.Value).Path("SyncedState/Obj"); if (o == null) continue;
                bool c = false;
                switch (st.Kind)
                {
                    case 'W': { var e = o.Path("WorldState/StateId/Dynamic_Enum_Value_Type"); c |= SetIf(e, "EnumValue", st.B); if (c || !string.Equals(e.S("EnumAsset"), st.A, StringComparison.OrdinalIgnoreCase)) SetIf(e, "EnumAsset", st.A); break; }
                    case 'L': case 'G': c |= SetIf(o, "LoadoutConfig", st.A); break;
                    case 'C': c |= SetIf(o, "HeroCharacter", st.A); break;
                    case 'N': c |= SetIf(o, "LightingMode", st.A); break;
                }
                SetIf(o, "DebugStateSource", kv.Value.Source); SetIf(o, "MissionHash", kv.Value.MissionHash);
                if (c) changed++;
            }
            return changed;
        }
        void SetMindCabin(StoryMission post)
        {
            var rs = SystemData.F("RestoreStateData");
            if (rs != null && rs.Values.Count > 0)
            {
                var first = rs.Values.Cast<Obj>().FirstOrDefault(r => r.Path("RestoreData/Obj") != null && r.Path("RestoreData/Obj").S("Owner") == "ObjectiveSystem") ?? (Obj)rs.Values[0];
                rs.Values.Clear(); rs.Values.Add(first);
                if (post != null)
                {
                    var c = first.Clone(); var o = c.Path("RestoreData/Obj");
                    Put(o, "Owner", "MindCabin"); Put(o, "PrimaryMission", post.Hash); Put(o, "SelectedMission", post.Name); Put(o, "AutoCheckpointEnabled", (byte)0);
                    rs.Values.Add(c);
                }
            }
            var ext = ObjectiveSystem.O("ExternalActivityData"); var stack = ext == null ? null : ext.F("ActivityStack");
            if (stack == null) return;
            stack.Values.Clear(); stack.Type = (FType)0x13;
            if (post != null)
            {
                var en = new Obj(); en.Fields.Add(Str("EnumAsset", "enums/externalactivities.dynamicenum")); en.Fields.Add(Str("EnumValue", "MindCabin"));
                var ty = new Obj(); ty.Fields.Add(O("Dynamic_Enum_Value_Type", en));
                var a = new Obj(); a.Fields.Add(O("ActivityType", ty)); a.Fields.Add(Str("CurrentState", "Active")); a.Fields.Add(I("RestoreLayerIndex", 1));
                a.Fields.Add(U("DevstatsSegmentId", Hash.Crc32("save_editor_segment_MindCabin") | 1u)); a.Fields.Add(U("PauseRefCount", 0));
                stack.Type = FType.Obj; stack.Values.Add(a);
            }
        }

        /// <summary>Moves the save to the start of an objective the way the game sets a save up when a mission is started
        /// directly: earlier story missions finished, this mission active with the objective running, the objective's own
        /// checkpoint, and the world, loadout and lighting states the story has set by that point.</summary>
        public void JumpTo(StoryObjective target, bool resetLater)
        {
            var tm = target.Mission;
            var nodes = new Dictionary<uint, MissionInfo>(); foreach (var m in Missions()) nodes[m.Hash] = m;
            if (!nodes.ContainsKey(tm.Hash)) throw new InvalidOperationException("This save has no entry for mission " + tm.Name + ".");
            string missionGraph = nodes[tm.Hash].Graph;
            uint seg = Segment(tm.Name);
            int n = Changes.Count;
            foreach (var sm in Story.Missions)
            {
                MissionInfo mi; if (!nodes.TryGetValue(sm.Hash, out mi)) continue;
                string want;
                if (sm == tm) want = "kActive";
                else if (sm.Name == "GP_LOBBY" || Story.IsBefore(sm, tm)) want = "kCompleteFinished";
                else if (sm.Name == "NIGHTMARE_ENDING" && tm.Name == "POST_GAME_MIND_CABIN") want = "kAvailable";
                else if (sm.Hub || resetLater || mi.State == "kActive" || mi.State == "kAvailable") want = "kInactive";
                else want = mi.State;
                bool diff = mi.State != want;
                ApplyMissionState(mi, want, sm == tm ? target.Hash : 0, sm == tm ? seg : 0, resetLater);
                if (diff) Log("Mission " + sm.Name + " -> " + want);
            }
            // objective data is only kept for missions that are running
            var g = ObjectiveSystem.O("GraphDataTable");
            foreach (var gf in g.Fields.ToList())
            {
                if (gf.Name == missionGraph) continue;
                var sm = Story.Missions.FirstOrDefault(x => string.Equals(x.GraphKey, gf.Name, StringComparison.OrdinalIgnoreCase));
                if (sm == null) continue;
                MissionInfo mi;
                if (sm == tm || !nodes.TryGetValue(sm.Hash, out mi) || mi.State != "kActive") g.Fields.Remove(gf);
            }
            g.Fields.Add(BuildObjectiveGraph(target, seg));

            var p = SystemData.O("PrimaryObjective"); p["MissionHash"] = tm.Hash; p["ObjectiveHash"] = target.Hash;
            Put(SystemData, "PlayerSelectedMission", tm.Hash);

            SetMindCabin(tm.Name == "POST_GAME_MIND_CABIN" ? tm : null);
            // the system's own restore point holds the world as it stood just before this mission began
            var states = Story.StatesAt(target, true); var before = Story.StatesAt(target, false);
            int sc = 0;
            foreach (var r in RestorePoints())
            {
                var t = r.Path("SyncStates/SyncedStateTable"); if (t == null) continue;
                ApplyStates(t, r.S("Owner") == "ObjectiveSystem" ? before : states);
            }
            var cur = SystemData.Path("CurrentStatesRestorePoint/SyncedStateTable");
            if (cur != null) sc = ApplyStates(cur, states);
            ResolvedState light;
            if (states.TryGetValue("0x00000000a3521105", out light) && light.State.A.Length > 0) Put(SaveFileData, "CurrentLightingMode", light.State.A);
            SetCheckpoint(Story.CheckpointFor(target), true);
            int ac = SyncActivities(target, resetLater);
            Changes.RemoveRange(n, Changes.Count - n);   // one readable line instead of dozens
            Log("Go to " + tm.Name + " / " + target.Name + "  (checkpoint " + Checkpoint + ", loadout " + Pretty(Loadout) + ", " + sc + " world states and " + ac + " activity cards updated)");
        }

        /// <summary>Brings the mission and objective activity cards in line with a story position, as the game does:
        /// finished for everything already played, active for the mission in progress, not started for the rest.</summary>
        int SyncActivities(StoryObjective target, bool resetLater)
        {
            var want = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var before = target.Mission.Before(target.Index);
            foreach (var a in Story.Activities)
            {
                var ms = a.Missions.Select(Story.Mission).Where(x => x != null).ToList(); if (ms.Count == 0) continue;
                string st;
                if (a.Objective.Length == 0)
                    st = ms.Contains(target.Mission) ? "kActive" : ms.All(x => Story.IsBefore(x, target.Mission)) ? "kFinished" : "kNotStarted";
                else if (ms[0] == target.Mission) { var o = ms[0].Objective(a.Objective); st = o != null && before.Contains(o.Index) ? "kFinished" : "kNotStarted"; }
                else st = Story.IsBefore(ms[0], target.Mission) ? "kFinished" : "kNotStarted";
                want[a.Id] = st;
            }
            var missionCards = new HashSet<string>(Story.Activities.Where(x => x.Objective.Length == 0).Select(x => x.Id), StringComparer.OrdinalIgnoreCase);
            int n = 0;
            foreach (var a in Activities())
            {
                string st; if (a.Id == null || !want.TryGetValue(a.Id, out st)) continue;
                if (st == "kNotStarted" && !resetLater && a.State != "kActive") continue;
                bool vis = st == "kActive";
                if (a.State == st && (Convert.ToByte(a.Save["Visible"]) != 0) == vis) continue;
                a.Save["State"] = st; a.Save["Visible"] = (byte)(vis ? 1 : 0); n++;
                // the game drops finished mission cards to the bottom of its list
                if (a.Save.Has("DisplayPriority") && missionCards.Contains(a.Id))
                    a.Save["DisplayPriority"] = st == "kFinished" ? "kLowest" : (a.Save.S("DisplayPriority") == "kLowest" ? "kNormal" : a.Save.S("DisplayPriority"));
            }
            return n;
        }

        /// <summary>Finishes or resets the activity cards that belong to the given missions.</summary>
        public int SetMissionActivities(IEnumerable<string> missions, string state)
        {
            var set = new HashSet<string>(missions); var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var a in Story.Activities) if (a.Missions.Any(set.Contains)) ids.Add(a.Id);
            int n = 0;
            foreach (var a in Activities())
                if (a.Id != null && (ids.Contains(a.Id) || set.Any(m => a.Id == m || a.Id.StartsWith(m + "_"))) && a.State != state) { SetActivity(a, state, null); n++; }
            return n;
        }

        // --------------------------------------------------------------------------- safety
        /// <summary>True when the save is past the part of the game that ships in the first install chunk (the Telambang
        /// prologue). From there on the game checks that everything is installed before it lets you continue.</summary>
        public bool NeedsFullInstall()
        {
            var im = Story.Mission(Story.InstallMission); if (im == null) return false;
            foreach (var m in Missions())
            {
                var sm = Story.Mission(m.Hash); if (sm == null || sm.Name == "GP_LOBBY") continue;
                if (sm == im && m.State == "kCompleteFinished") return true;
                if ((sm.Index > im.Index || sm.Hub) && m.State != "kInactive") return true;
            }
            return false;
        }
        public MissionInfo ActiveStoryMission()
        {
            MissionInfo best = null;
            foreach (var m in Missions()) { var sm = Story.Mission(m.Hash); if (m.State == "kActive" && sm != null && !sm.Hub && sm.Name != "GP_LOBBY") { if (best == null || m.Hash == PrimaryMission) best = m; } }
            return best;
        }

        /// <summary>Problems that could stop the save from loading as intended. Empty list = fine.</summary>
        public List<string> Check(GameSetup game = null)
        {
            var p = new List<string>();
            string chk = Checkpoint;
            if (!IsKnownCheckpoint(chk))
                p.Add("The checkpoint \"" + chk + "\" does not exist in the game's level data. The game falls back to a test checkpoint in Madripoor (outside the Princess Bar) when it cannot find the one in the save.");
            else
            {
                var owners = MissionsOfCheckpoint(chk); string mis = owners.Count > 0 ? owners[0] : null;
                var act = ActiveStoryMission();
                if (mis != null && act != null && !owners.Contains(act.Name) && !Missions().Any(m => m.State == "kActive" && owners.Contains(m.Name)))
                    p.Add("The checkpoint belongs to " + string.Join(" / ", owners) + " but the mission in progress is " + act.Name + ". Use \"Go there\" on the Story tab so mission, objective and checkpoint match.");
                if (mis != null && act == null && !Missions().Any(m => m.State == "kActive" && owners.Contains(m.Name)))
                    p.Add("No story mission is in progress, so the game has nothing to resume at this checkpoint. Use \"Go there\" on the Story tab.");
            }
            if (Campaign != null && Campaign != "kBaseGame") p.Add("Campaign is " + Campaign + " instead of kBaseGame.");
            var ld = Loadout;
            if (!string.IsNullOrEmpty(ld) && !Catalog.Loadouts.Contains(ld, StringComparer.OrdinalIgnoreCase)) p.Add("Mission loadout " + ld + " is not one of the game's loadouts.");
            if (NeedsFullInstall())
            {
                if (game == null || !game.Found)
                    p.Add("This save is past the prologue, where the game starts checking that it is fully installed (the \"GAME DATA REQUIRED - Game content not fully installed\" message). Point the editor at the game folder on the Game setup tab so it can check the fix is in place.");
                else if (!game.InstallCheckOff)
                    p.Add("This save is past the prologue and the game's install check is still on, so Continue will show \"GAME DATA REQUIRED - Game content not fully installed\". Turn it off on the Game setup tab.");
            }
            if (game != null && game.Found && game.ForcedCheckpoint != null && game.ForcedCheckpoint != chk)
                p.Add("commandline.txt forces the checkpoint " + game.ForcedCheckpoint + ", which is not the one in this save (" + chk + "). Remove that line on the Game setup tab or the game may start somewhere else.");
            return p;
        }
    }
}
