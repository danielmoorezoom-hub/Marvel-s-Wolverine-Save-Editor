// Wolverine Save Editor - main window.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WolverineSave
{
    public class MainForm : Form
    {
        SaveFile file; SaveModel model; string path; GameSetup game;
        bool loading;

        ComboBox slotBox; Button browseBtn, reloadBtn, saveBtn, restoreBtn;
        TabControl tabs; ToolStripStatusLabel status;

        // story
        ComboBox chkBox, goMissionBox, goObjBox, charBox, loadoutBox; CheckBox showAllChk, resetLaterChk, ngpChk; Label chkInfo, goInfo, nowInfo; NumericUpDown pctBox;
        DataGridView missionGrid, objectiveGrid;
        // activities
        TextBox actFilter; ComboBox actRegion; DataGridView actGrid;
        // gear
        Panel slotsPanel; DataGridView partsGrid, skillsGrid, tacticsGrid, techGrid, xpGrid;
        // unlocks
        DataGridView nightGrid, collGrid, rewardGrid, galleryGrid;
        // changes
        ListBox changeList; TextBox checkBox;
        // advanced
        TreeView tree; TextBox valueBox; Button applyValueBtn; Label valueInfo;
        // game setup
        TabPage changesPage, gamePage; TextBox gameFolderBox, cmdBox; Label installLbl, forcedLbl, needLbl; Button installBtn, forcedBtn;

        public MainForm(string startPath)
        {
            Text = "Wolverine Save Editor 1.2";
            Width = 1180; Height = 820; StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9f);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            BuildUi();
            game = new GameSetup(GameSetup.Find());
            RefreshGame();
            FillSlots(startPath);
        }

        // =================================================================================== layout
        static Button Btn(string text, EventHandler h, int w = 0)
        {
            var b = new Button { Text = text, AutoSize = w == 0, Height = 28, Margin = new Padding(3) };
            if (w > 0) b.Width = w;
            b.Click += h; return b;
        }
        static DataGridView Grid()
        {
            var g = new DataGridView
            {
                Dock = DockStyle.Fill, AllowUserToAddRows = false, AllowUserToDeleteRows = false, RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EditMode = DataGridViewEditMode.EditOnEnter,
            };
            g.CurrentCellDirtyStateChanged += (s, e) => { if (g.IsCurrentCellDirty) g.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            g.DataError += (s, e) => { e.ThrowException = false; };
            return g;
        }
        static DataGridViewTextBoxColumn TextCol(string h, int weight = 100, bool ro = true)
        { return new DataGridViewTextBoxColumn { HeaderText = h, ReadOnly = ro, FillWeight = weight, SortMode = DataGridViewColumnSortMode.Automatic }; }
        static DataGridViewComboBoxColumn ComboCol(string h, string[] items, int weight = 60)
        {
            var c = new DataGridViewComboBoxColumn { HeaderText = h, FillWeight = weight, FlatStyle = FlatStyle.Flat, DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton };
            c.Items.AddRange(items); return c;
        }
        static readonly Dictionary<string, string> Friendly = new Dictionary<string, string> {
            { "kInactive", "Not started" }, { "kAvailable", "Available" }, { "kActive", "In progress" }, { "kCompleteFinished", "Complete" }, { "kComplete", "Complete" },
            { "kNotStarted", "Not started" }, { "kFinished", "Finished" } };
        static string Fr(string engine) { string f; return engine != null && Friendly.TryGetValue(engine, out f) ? f : engine; }
        static string En(string friendly, string[] allowed) { foreach (var a in allowed) if (Fr(a) == friendly || a == friendly) return a; return friendly; }
        static string[] FrAll(string[] a) { return a.Select(Fr).ToArray(); }
        static DataGridViewCheckBoxColumn CheckCol(string h, int weight = 30) { return new DataGridViewCheckBoxColumn { HeaderText = h, FillWeight = weight }; }
        static FlowLayoutPanel Row(params Control[] cs)
        {
            var p = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, WrapContents = true, Padding = new Padding(4, 2, 4, 2) };
            p.Controls.AddRange(cs); return p;
        }
        static Label L(string t, int w = 0) { var l = new Label { Text = t, AutoSize = w == 0, TextAlign = ContentAlignment.MiddleLeft, Height = 28, Margin = new Padding(3, 6, 3, 3) }; if (w > 0) l.Width = w; return l; }

        void BuildUi()
        {
            var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(6), WrapContents = false };
            slotBox = new ComboBox { Width = 560, DropDownStyle = ComboBoxStyle.DropDownList, Margin = new Padding(3, 5, 3, 3) };
            slotBox.SelectedIndexChanged += (s, e) => { if (!loading && slotBox.SelectedItem != null) Open(((SlotItem)slotBox.SelectedItem).Path); };
            browseBtn = Btn("Open save file...", (s, e) => Browse());
            reloadBtn = Btn("Reload", (s, e) => { if (path != null) Open(path); });
            saveBtn = Btn("Save changes", (s, e) => DoSave()); saveBtn.Font = new Font(Font, FontStyle.Bold);
            restoreBtn = Btn("Restore a backup...", (s, e) => RestoreBackup());
            top.Controls.AddRange(new Control[] { L("Save:"), slotBox, browseBtn, reloadBtn, saveBtn, restoreBtn });

            tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(StoryTab());
            tabs.TabPages.Add(ActivitiesTab());
            tabs.TabPages.Add(GearTab());
            tabs.TabPages.Add(UnlocksTab());
            tabs.TabPages.Add(changesPage = ChangesTab());
            tabs.TabPages.Add(AdvancedTab());
            tabs.TabPages.Add(gamePage = GameTab());
            tabs.SelectedIndexChanged += (s, e) => { if (tabs.SelectedTab == changesPage) RefreshChanges(); if (tabs.SelectedTab == gamePage) { game.Reload(); RefreshGame(); } };

            var ss = new StatusStrip(); status = new ToolStripStatusLabel("Open a save to start.") { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
            ss.Items.Add(status);
            Controls.Add(tabs); Controls.Add(top); Controls.Add(ss);
            EnableAll(false);
        }

        TabPage StoryTab()
        {
            var page = new TabPage("Story");
            goMissionBox = new ComboBox { Width = 290, DropDownStyle = ComboBoxStyle.DropDownList, MaxDropDownItems = 36 };
            goObjBox = new ComboBox { Width = 470, DropDownStyle = ComboBoxStyle.DropDownList, MaxDropDownItems = 30 };
            goMissionBox.SelectedIndexChanged += (s, e) => { if (!loading) FillGoObjectives(null); };
            goObjBox.SelectedIndexChanged += (s, e) => { if (!loading) UpdateGoInfo(); };
            resetLaterChk = new CheckBox { Text = "Reset later missions", AutoSize = true, Checked = true, Margin = new Padding(8, 7, 3, 3) };
            var goBtn = Btn("Go there", (s, e) => GoThere()); goBtn.Font = new Font(Font, FontStyle.Bold);
            goInfo = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(3, 7, 3, 3) };
            nowInfo = new Label { AutoSize = true, Margin = new Padding(3, 7, 3, 3) };

            chkBox = new ComboBox { Width = 560, DropDownStyle = ComboBoxStyle.DropDownList, MaxDropDownItems = 30 };
            chkBox.SelectedIndexChanged += (s, e) => { if (!loading) UpdateChkInfo(); };
            showAllChk = new CheckBox { Text = "Show test and unused checkpoints too", AutoSize = true, Margin = new Padding(8, 7, 3, 3) };
            showAllChk.CheckedChanged += (s, e) => FillCheckpoints();
            var setBtn = Btn("Set checkpoint only", (s, e) => { var it = chkBox.SelectedItem as NamedItem; if (it != null) { model.SetCheckpoint(it.Value); Changed(); } });
            chkInfo = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(3, 7, 3, 3) };

            charBox = new ComboBox { Width = 130, DropDownStyle = ComboBoxStyle.DropDownList };
            charBox.SelectedIndexChanged += (s, e) => { if (!loading && charBox.SelectedItem != null) { model.Character = (string)charBox.SelectedItem; Changed(); } };
            loadoutBox = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList, MaxDropDownItems = 36 };
            loadoutBox.SelectedIndexChanged += (s, e) => { if (!loading && loadoutBox.SelectedItem != null) { model.Loadout = ((NamedItem)loadoutBox.SelectedItem).Value; Changed(); } };
            pctBox = new NumericUpDown { Width = 60, Minimum = 0, Maximum = 100, Margin = new Padding(3, 5, 3, 3) };
            pctBox.ValueChanged += (s, e) => { if (!loading && model != null) { model.SetGamePercent((float)pctBox.Value / 100f); Changed(false); } };
            ngpChk = new CheckBox { Text = "New Game+ unlocked", AutoSize = true, Margin = new Padding(8, 7, 3, 3) };
            ngpChk.CheckedChanged += (s, e) => { if (!loading && model != null) { model.NewGamePlusUnlocked = ngpChk.Checked; Changed(false); } };

            missionGrid = Grid();
            missionGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("#", 18), TextCol("Mission", 150), TextCol("Region", 55), ComboCol("State", FrAll(SaveModel.MissionStates), 70), TextCol("Times completed", 40), CheckCol("Rewards given", 40) });
            missionGrid.Columns[5].ReadOnly = true;
            foreach (DataGridViewColumn c in missionGrid.Columns) c.SortMode = DataGridViewColumnSortMode.NotSortable;
            missionGrid.CellValueChanged += (s, e) =>
            {
                if (loading || e.RowIndex < 0 || e.ColumnIndex != 3) return;
                var m = (MissionInfo)missionGrid.Rows[e.RowIndex].Tag;
                model.SetMissionState(m, En((string)missionGrid.Rows[e.RowIndex].Cells[3].Value, SaveModel.MissionStates), true); Changed(false); RefreshMissionRow(missionGrid.Rows[e.RowIndex]);
            };
            objectiveGrid = Grid();
            objectiveGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Objective", 200), TextCol("Its checkpoint", 150), ComboCol("State", FrAll(SaveModel.ObjectiveStates), 60) });
            foreach (DataGridViewColumn c in objectiveGrid.Columns) c.SortMode = DataGridViewColumnSortMode.NotSortable;
            objectiveGrid.CellValueChanged += (s, e) =>
            {
                if (loading || e.RowIndex < 0 || e.ColumnIndex != 2) return;
                model.SetObjectiveState((ObjectiveInfo)objectiveGrid.Rows[e.RowIndex].Tag, En((string)objectiveGrid.Rows[e.RowIndex].Cells[2].Value, SaveModel.ObjectiveStates)); Changed(false);
            };

            var bulk = Row(L("Selected missions:"),
                Btn("Complete", (s, e) => BulkMissions("kCompleteFinished")),
                Btn("Make active", (s, e) => BulkMissions("kActive")),
                Btn("Reset", (s, e) => BulkMissions("kInactive")),
                Btn("Finish their activities", (s, e) => FinishMissionActivities()));

            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical };
            bool splitSet = false;
            page.Layout += (s, e) => { int w = split.Width; if (!splitSet && w > 400) { try { split.SplitterDistance = w * 52 / 100; splitSet = true; } catch { } } };
            var left = new Panel { Dock = DockStyle.Fill };
            left.Controls.Add(missionGrid); left.Controls.Add(bulk); left.Controls.Add(Row(L("Missions, in the order the story plays them")));
            var right = new Panel { Dock = DockStyle.Fill };
            right.Controls.Add(objectiveGrid); right.Controls.Add(Row(L("Objectives of the mission in progress (the game only keeps these while a mission runs)")));
            split.Panel1.Controls.Add(left); split.Panel2.Controls.Add(right);

            var head = new Panel { Dock = DockStyle.Top, Height = 196 };
            var r5 = Row(L("Character:", 90), charBox, L("Mission loadout:"), loadoutBox, L("Completion %:"), pctBox, ngpChk);
            var r4 = Row(L("", 90), chkInfo);
            var r3 = Row(L("Checkpoint:", 90), chkBox, setBtn, showAllChk);
            var r2 = Row(L("", 90), goInfo);
            var r1 = Row(L("Go to:", 90), goMissionBox, goObjBox, goBtn, resetLaterChk);
            var r0 = Row(L("Now:", 90), nowInfo);
            head.Controls.Add(r5); head.Controls.Add(r4); head.Controls.Add(r3); head.Controls.Add(r2); head.Controls.Add(r1); head.Controls.Add(r0);
            page.Controls.Add(split); page.Controls.Add(head);
            return page;
        }

        TabPage ActivitiesTab()
        {
            var page = new TabPage("Activities");
            actFilter = new TextBox { Width = 260 }; actFilter.TextChanged += (s, e) => FillActivities();
            actRegion = new ComboBox { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            actRegion.Items.AddRange(new object[] { "All regions", "Telambang", "Canada", "Japan", "Madripoor", "Nightmare / Mind Cabin", "Collectibles", "Other" });
            actRegion.SelectedIndex = 0; actRegion.SelectedIndexChanged += (s, e) => FillActivities();
            actGrid = Grid();
            actGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Activity", 220), TextCol("Region", 60), ComboCol("State", FrAll(SaveModel.ActivityStates), 60), CheckCol("Visible on map", 40) });
            actGrid.CellValueChanged += (s, e) =>
            {
                if (loading || e.RowIndex < 0) return;
                var a = (ActivityInfo)actGrid.Rows[e.RowIndex].Tag;
                if (e.ColumnIndex == 2) model.SetActivity(a, En((string)actGrid.Rows[e.RowIndex].Cells[2].Value, SaveModel.ActivityStates), null);
                if (e.ColumnIndex == 3) model.SetActivity(a, null, (bool)actGrid.Rows[e.RowIndex].Cells[3].Value);
                Changed(false);
            };
            var bar = Row(L("Search:"), actFilter, L("Region:"), actRegion,
                Btn("Finish all shown", (s, e) => BulkActivities("kFinished")),
                Btn("Reset all shown", (s, e) => BulkActivities("kNotStarted")));
            page.Controls.Add(actGrid); page.Controls.Add(bar);
            return page;
        }

        TabPage GearTab()
        {
            var page = new TabPage("Gear && loadout");
            slotsPanel = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
            partsGrid = OwnGrid("Suits and claws", true);
            skillsGrid = OwnGrid("Skill", false);
            tacticsGrid = OwnGrid("Tactic", false); tacticsGrid.Columns.Add(CheckCol("Equipped", 30));
            techGrid = OwnGrid("Technique", false);
            xpGrid = Grid();
            xpGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Currency", 120), TextCol("Amount owned", 60, false), TextCol("Levels rewarded", 50, false), TextCol("Skill points rewarded", 50, false) });
            xpGrid.CellValueChanged += XpChanged;
            var gt = new TabControl { Dock = DockStyle.Fill };
            gt.TabPages.Add(Wrap("Suits && claws", partsGrid, "part"));
            gt.TabPages.Add(Wrap("Skills", skillsGrid, "skill"));
            gt.TabPages.Add(Wrap("Tactics", tacticsGrid, "tactic"));
            gt.TabPages.Add(Wrap("Techniques", techGrid, "technique"));
            var xpPage = new TabPage("XP && points"); xpPage.Controls.Add(xpGrid);
            xpPage.Controls.Add(Row(L("Amounts are what the game shows as owned. Levels/skill points rewarded only stop the game re-granting level-ups.")));
            gt.TabPages.Add(xpPage);
            page.Controls.Add(gt); page.Controls.Add(slotsPanel);
            return page;
        }
        DataGridView OwnGrid(string what, bool withCategory)
        {
            var g = Grid();
            g.Columns.Add(CheckCol("Owned", 25));
            g.Columns.Add(TextCol(what, 160));
            if (withCategory) g.Columns.Add(TextCol("Type", 40));
            g.Columns.Add(TextCol("Game file", 160));
            g.CellValueChanged += (s, e) =>
            {
                if (loading || e.RowIndex < 0) return;
                var row = g.Rows[e.RowIndex]; var t = (Tuple<string, string>)row.Tag;
                if (e.ColumnIndex == 0)
                {
                    model.SetOwned(t.Item1, t.Item2, (bool)row.Cells[0].Value);
                    loading = true; row.Cells[0].Value = model.Owns(t.Item1, t.Item2); loading = false;   // worn parts cannot be removed
                    if (t.Item1 == "part") FillSlots2();
                    Changed(false);
                }
                else if (g == tacticsGrid && e.ColumnIndex == g.Columns.Count - 1)
                {
                    var own = model.Tactics().FirstOrDefault(x => string.Equals(x.Path, t.Item2, StringComparison.OrdinalIgnoreCase));
                    if (own == null) { model.SetOwned("tactic", t.Item2, true); own = model.Tactics().First(x => string.Equals(x.Path, t.Item2, StringComparison.OrdinalIgnoreCase)); }
                    model.SetTacticEquipped(own, (bool)row.Cells[e.ColumnIndex].Value);
                    loading = true; row.Cells[0].Value = true; loading = false; Changed(false);
                }
            };
            return g;
        }
        TabPage Wrap(string title, DataGridView g, string kind)
        {
            var p = new TabPage(title);
            p.Controls.Add(g);
            p.Controls.Add(Row(Btn("Own all", (s, e) => SetAllOwned(g, kind, true)), Btn("Own none", (s, e) => SetAllOwned(g, kind, false)),
                L("Ticking adds the item to your inventory the way the game does when you earn it.")));
            return p;
        }

        TabPage UnlocksTab()
        {
            var page = new TabPage("Unlocks && progress");
            var t = new TabControl { Dock = DockStyle.Fill };
            nightGrid = Grid();
            nightGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Challenge", 140), CheckCol("Unlocked"), CheckCol("Viewed"), CheckCol("Attempted"), CheckCol("Main goal done"), TextCol("Best tier", 30, false) });
            nightGrid.CellValueChanged += (s, e) => GridFieldChanged(nightGrid, e, new[] { null, "Unlocked", "Viewed", "Attempted", "PrimaryChallengeComplete", "BestTier" }, "Nightmare challenge");
            collGrid = Grid();
            collGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Collectible type", 80), TextCol("Collectible", 80), CheckCol("Discovered"), CheckCol("Collected") });
            collGrid.CellValueChanged += (s, e) => GridFieldChanged(collGrid, e, new[] { null, null, "Discovered", "Completed" }, "Collectible");
            rewardGrid = Grid();
            rewardGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Reward", 160), CheckCol("Granted at least once") });
            rewardGrid.CellValueChanged += (s, e) => GridFieldChanged(rewardGrid, e, new[] { null, "HasBeenGrantedAtLeastOnce" }, "Reward");
            galleryGrid = Grid();
            galleryGrid.Columns.AddRange(new DataGridViewColumn[] { TextCol("Gallery entry", 160), CheckCol("Viewed") });
            galleryGrid.CellValueChanged += (s, e) => GridFieldChanged(galleryGrid, e, new[] { null, "Viewed" }, "Gallery entry");
            t.TabPages.Add(Checklist("Nightmare challenges", nightGrid));
            t.TabPages.Add(Checklist("Collectibles", collGrid));
            t.TabPages.Add(Checklist("Progression rewards", rewardGrid));
            t.TabPages.Add(Checklist("Gallery", galleryGrid));
            page.Controls.Add(t);
            return page;
        }
        TabPage Checklist(string title, DataGridView g)
        {
            var p = new TabPage(title); p.Controls.Add(g);
            p.Controls.Add(Row(Btn("Tick column for all rows...", (s, e) => TickColumn(g, true)), Btn("Untick column for all rows...", (s, e) => TickColumn(g, false))));
            return p;
        }

        TabPage ChangesTab()
        {
            var page = new TabPage("Changes && checks");
            changeList = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false };
            checkBox = new TextBox { Dock = DockStyle.Top, Height = 120, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical };
            page.Controls.Add(changeList); page.Controls.Add(Row(L("Changes waiting to be saved:")));
            page.Controls.Add(checkBox); page.Controls.Add(Row(L("Load-safety checks:")));
            return page;
        }

        TabPage AdvancedTab()
        {
            var page = new TabPage("Advanced");
            tree = new TreeView { Dock = DockStyle.Fill, HideSelection = false };
            tree.BeforeExpand += (s, e) => ExpandNode(e.Node);
            tree.AfterSelect += (s, e) => ShowValue(e.Node);
            valueBox = new TextBox { Width = 420 };
            valueInfo = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(3, 7, 3, 3) };
            applyValueBtn = Btn("Apply", (s, e) => ApplyValue());
            page.Controls.Add(tree);
            page.Controls.Add(Row(L("Value:"), valueBox, applyValueBtn, valueInfo));
            page.Controls.Add(Row(L("Every field in the save. Change single values here only if you know what they do.")));
            return page;
        }

        TabPage GameTab()
        {
            var page = new TabPage("Game setup");
            gameFolderBox = new TextBox { Width = 620, ReadOnly = true, Margin = new Padding(3, 5, 3, 3) };
            installLbl = new Label { AutoSize = true, Margin = new Padding(3, 7, 12, 3) };
            forcedLbl = new Label { AutoSize = true, Margin = new Padding(3, 7, 12, 3) };
            needLbl = new Label { AutoSize = true, Margin = new Padding(3, 7, 3, 3) };
            installBtn = Btn("Turn the install check off", (s, e) => FixInstall(true));
            forcedBtn = Btn("Remove the forced checkpoint", (s, e) =>
            {
                try { game.RemoveForcedCheckpoint(); } catch (Exception ex) { MessageBox.Show(this, "Could not change commandline.txt:\n" + ex.Message, Text); }
                RefreshGame(); if (model != null) Changed(false);
            });
            cmdBox = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, Font = new Font("Consolas", 9f) };
            var help = new Label
            {
                Dock = DockStyle.Top, Height = 96, Padding = new Padding(8, 6, 8, 0), ForeColor = Color.DimGray,
                Text = "The game ships in two install chunks. The first one ends with the Telambang prologue (objective GP_TEL_COMPOUND_ARKADY_CINE_OUTRO). " +
                       "Once a save is past that point, the game asks the console whether everything is installed before it lets you continue. The emulator does not answer that, " +
                       "so you get \"GAME DATA REQUIRED - Game content not fully installed, unable to proceed\". The line " + GameSetup.InstallFixLine +
                       " in commandline.txt switches that question off; all the game files are on disk anyway.\r\n" +
                       "A -checkpoint line in the same file makes the game start at that checkpoint whatever the save says, so remove it when you want the save to decide."
            };
            page.Controls.Add(cmdBox);
            page.Controls.Add(Row(L("commandline.txt as it is now (the editor keeps a copy before every change, and commandline.txt.original is never overwritten):")));
            page.Controls.Add(Row(L("Forced start:", 110), forcedLbl, forcedBtn));
            page.Controls.Add(Row(L("Install check:", 110), installLbl, installBtn));
            page.Controls.Add(Row(L("This save:", 110), needLbl));
            page.Controls.Add(Row(L("Game folder:", 110), gameFolderBox, Btn("Browse...", (s, e) => BrowseGame()), Btn("Read again", (s, e) => { game.Reload(); RefreshGame(); if (model != null) Changed(false); })));
            page.Controls.Add(help);
            return page;
        }
        void BrowseGame()
        {
            using (var d = new FolderBrowserDialog { Description = "Pick the game folder (the one with commandline.txt, eboot.bin and toc in it, usually named PPSA03671-app0)" })
            {
                if (game.Folder != null && Directory.Exists(game.Folder)) d.SelectedPath = game.Folder;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                if (!GameSetup.LooksLikeGame(d.SelectedPath)) { MessageBox.Show(this, "That folder has no commandline.txt next to eboot.bin / toc, so it is not the game folder.", Text); return; }
                game = new GameSetup(d.SelectedPath); GameSetup.Remember("game", d.SelectedPath);
                RefreshGame(); if (model != null) Changed(false);
            }
        }
        void RefreshGame()
        {
            if (gameFolderBox == null) return;
            bool found = game != null && game.Found;
            gameFolderBox.Text = found ? game.Folder : "(not found - press Browse)";
            bool need = model != null && model.NeedsFullInstall();
            needLbl.Text = model == null ? "No save open." : need ? "Past the prologue: the game will run its install check when you continue this save." : "Still inside the prologue: the install check does not apply yet.";
            if (!found)
            {
                installLbl.Text = "Unknown - the game folder was not found."; installLbl.ForeColor = Color.Firebrick;
                forcedLbl.Text = "Unknown."; forcedLbl.ForeColor = Color.DimGray; installBtn.Enabled = forcedBtn.Enabled = false; cmdBox.Text = ""; return;
            }
            bool off = game.InstallCheckOff;
            installLbl.Text = off ? "Off. Saves past the prologue can be continued." : "On. Saves past the prologue will show \"GAME DATA REQUIRED\".";
            installLbl.ForeColor = off ? Color.DarkGreen : Color.Firebrick; installBtn.Enabled = !off;
            string fc = game.ForcedCheckpoint; var other = game.StartOverrides;
            forcedLbl.Text = (fc == null ? "No forced checkpoint; the save decides where you start." : "commandline.txt forces checkpoint " + fc + (model != null && model.Checkpoint == fc ? " (same as this save)." : " - this save's own checkpoint is ignored."))
                + (other.Count > 0 ? "  Also: " + string.Join("  ", other) : "");
            forcedLbl.ForeColor = fc == null || (model != null && model.Checkpoint == fc) ? Color.DimGray : Color.Firebrick; forcedBtn.Enabled = fc != null;
            cmdBox.Text = string.Join("\r\n", game.Lines);
        }
        bool FixInstall(bool tell)
        {
            try { game.TurnInstallCheckOff(); }
            catch (Exception ex) { MessageBox.Show(this, "Could not change commandline.txt:\n" + ex.Message + "\n\nYou can add this line to it yourself, above the -buildname line:\n" + GameSetup.InstallFixLine, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            RefreshGame(); if (model != null) Changed(false);
            if (tell) SetStatus("Install check switched off in " + game.CommandLinePath);
            return true;
        }

        // =================================================================================== slots / open / save
        class SlotItem { public string Path, Label; public override string ToString() { return Label; } }
        class NamedItem { public string Value, Label; public override string ToString() { return Label; } }

        static IEnumerable<string> CandidateFolders()
        {
            string exe = Path.GetDirectoryName(Application.ExecutablePath);
            var roots = new List<string> { exe, Path.Combine(exe, ".."), Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads" };
            foreach (var r in roots)
            {
                string[] dirs;
                try { dirs = Directory.GetDirectories(r); } catch { continue; }
                foreach (var d in dirs.Concat(new[] { r }))
                {
                    string sd = Path.Combine(d, "_SaveData", "PPSA03671");
                    if (Directory.Exists(sd)) yield return sd;
                }
            }
        }
        void FillSlots(string startPath)
        {
            loading = true;
            slotBox.Items.Clear();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var root in CandidateFolders())
            {
                string[] dirs; try { dirs = Directory.GetDirectories(root); } catch { continue; }
                foreach (var d in dirs.OrderBy(x => x))
                {
                    string g = Path.Combine(d, "game.save");
                    if (File.Exists(g) && seen.Add(Path.GetFullPath(g)))
                        slotBox.Items.Add(new SlotItem { Path = g, Label = Path.GetFileName(d) + "   (" + File.GetLastWriteTime(g).ToString("g") + ")" });
                }
            }
            loading = false;
            if (startPath != null && File.Exists(startPath)) Open(startPath);
            else if (slotBox.Items.Count > 0) slotBox.SelectedIndex = 0;
        }
        void Browse()
        {
            using (var d = new OpenFileDialog { Filter = "Wolverine save (game.save)|game.save;*.save|All files|*.*", Title = "Open a Wolverine save" })
                if (d.ShowDialog(this) == DialogResult.OK) Open(d.FileName);
        }
        bool ConfirmDiscard()
        {
            if (model == null || model.Changes.Count == 0) return true;
            return MessageBox.Show(this, "You have " + model.Changes.Count + " unsaved changes. Discard them?", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
        void Open(string p)
        {
            if (!ConfirmDiscard()) return;
            try
            {
                var f = SaveFile.Load(p);
                file = f; model = new SaveModel(f); path = p;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not open the save:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }
            loading = true;
            bool listed = false;
            for (int i = 0; i < slotBox.Items.Count; i++)
                if (string.Equals(((SlotItem)slotBox.Items[i]).Path, p, StringComparison.OrdinalIgnoreCase)) { slotBox.SelectedIndex = i; listed = true; }
            if (!listed) { slotBox.Items.Add(new SlotItem { Path = p, Label = p }); slotBox.SelectedIndex = slotBox.Items.Count - 1; }
            loading = false;
            RefreshAll();
            EnableAll(true);
            SetStatus("Opened " + p);
        }
        void EnableAll(bool on) { tabs.Enabled = on; saveBtn.Enabled = on; reloadBtn.Enabled = on; restoreBtn.Enabled = on; }

        string BackupDir()
        {
            // not inside the save slot: the emulator rewrites that folder
            string slot = Path.GetFileName(Path.GetDirectoryName(path));
            string dir = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "WolverineSaveEditor-backups", slot);
            try { Directory.CreateDirectory(dir); return dir; }
            catch { dir = Path.Combine(Path.GetDirectoryName(path), "editor_backups"); Directory.CreateDirectory(dir); return dir; }
        }
        void DoSave()
        {
            if (model == null) return;
            game.Reload();
            if (model.NeedsFullInstall() && game.Found && !game.InstallCheckOff)
            {
                var r = MessageBox.Show(this, "This save is past the prologue, and the game's install check is still on. Continuing the save would show\n\n    GAME DATA REQUIRED\n    Game content not fully installed, unable to proceed.\n\n" +
                    "Switch the check off now? This adds the line\n    " + GameSetup.InstallFixLine + "\nto commandline.txt in the game folder (a copy of the file is kept).", Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (r == DialogResult.Cancel) return;
                if (r == DialogResult.Yes) FixInstall(false);
            }
            string forced = game.Found ? game.ForcedCheckpoint : null;
            if (forced != null && forced != model.Checkpoint)
            {
                var r = MessageBox.Show(this, "commandline.txt in the game folder has the line\n\n    -checkpoint " + forced + "\n\nwhich makes the game start there instead of at this save's checkpoint (" + model.Checkpoint + ").\n\n" +
                    "Remove that line so the save decides? (A copy of the file is kept.)", Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (r == DialogResult.Cancel) return;
                if (r == DialogResult.Yes) { try { game.RemoveForcedCheckpoint(); } catch (Exception ex) { MessageBox.Show(this, "Could not change commandline.txt:\n" + ex.Message, Text); } RefreshGame(); }
            }
            var problems = model.Check(game);
            if (problems.Count > 0)
            {
                var msg = "This save may not load the way you expect:\n\n- " + string.Join("\n\n- ", problems) + "\n\nSave anyway?";
                if (MessageBox.Show(this, msg, Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            }
            try
            {
                byte[] bytes = file.ToBytes();
                new SaveFile(bytes);   // must read back before it replaces anything
                string backupDir = BackupDir();
                string backup = Path.Combine(backupDir, "game.save." + DateTime.Now.ToString("yyyyMMdd-HHmmss"));
                File.Copy(path, backup, true);
                string tmp = Path.Combine(backupDir, "game.save.writing");
                File.WriteAllBytes(tmp, bytes);
                File.Copy(tmp, path, true); File.Delete(tmp);
                int n = model.Changes.Count;
                File.AppendAllText(Path.Combine(backupDir, "changes.log"), DateTime.Now + "  " + path + Environment.NewLine + string.Join(Environment.NewLine, model.Changes.Select(c => "    " + c)) + Environment.NewLine);
                model.Changes.Clear();
                RefreshChanges(); Changed(false);
                SetStatus("Saved " + n + " change" + (n == 1 ? "" : "s") + ". Backup: " + backup);
            }
            catch (Exception ex) { MessageBox.Show(this, "Saving failed, nothing was replaced:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        void RestoreBackup()
        {
            if (path == null) return;
            string dir = BackupDir();
            using (var d = new OpenFileDialog { InitialDirectory = dir, Title = "Pick a backup to put back", Filter = "Backups|game.save.*|All files|*.*" })
            {
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try { new SaveFile(File.ReadAllBytes(d.FileName)); }
                catch (Exception ex) { MessageBox.Show(this, "That file is not a readable save: " + ex.Message, Text); return; }
                if (MessageBox.Show(this, "Replace the current save with\n" + d.FileName + " ?", Text, MessageBoxButtons.YesNo) != DialogResult.Yes) return;
                File.Copy(path, Path.Combine(dir, "game.save." + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-before-restore"), true);
                File.Copy(d.FileName, path, true);
                if (model != null) model.Changes.Clear();
                Open(path);
            }
        }

        void SetStatus(string s) { status.Text = s; }
        void Changed(bool refresh = true)
        {
            if (refresh) RefreshStory();
            int n = model.Changes.Count;
            var probs = model.Check(game);
            SetStatus(n + " unsaved change" + (n == 1 ? "" : "s") + (probs.Count > 0 ? "   |   CHECK: " + probs[0] : ""));
            changesPage.Text = "Changes && checks (" + n + (probs.Count > 0 ? ", " + probs.Count + " warning" + (probs.Count == 1 ? "" : "s") : "") + ")";
            RefreshGame();
        }

        // =================================================================================== refresh
        void RefreshAll()
        {
            RefreshStory(); FillActivities(); FillGear(); FillUnlocks(); FillTree(); RefreshChanges();
            Changed(false);
        }
        void FillCheckpoints()
        {
            if (model == null) return;
            loading = true;
            chkBox.BeginUpdate();
            chkBox.Items.Clear();
            var seen = new HashSet<string>();
            Action<string, string> add = (c, who) => { if (seen.Add(c)) chkBox.Items.Add(new NamedItem { Value = c, Label = c + (who == null ? "" : "      [" + who + "]") }); };
            foreach (var m in Story.Missions)
            {
                if (m.Name == "GP_LOBBY") continue;
                if (m.StartCheckpoint.Length > 0) add(m.StartCheckpoint, m.Name + " start");
                foreach (var o in m.Objectives) if (o.Checkpoint.Length > 0) add(o.Checkpoint, m.Name);
                if (m.Available.Length > 0) add(m.Available, m.Name);
            }
            if (showAllChk.Checked) foreach (var c in Catalog.Checkpoints) add(c, SaveModel.MissionOfCheckpoint(c) ?? "not used by the story");
            if (!seen.Contains(model.Checkpoint)) { seen.Add(model.Checkpoint); chkBox.Items.Insert(0, new NamedItem { Value = model.Checkpoint, Label = model.Checkpoint + "      [current]" }); }
            foreach (NamedItem it in chkBox.Items) if (it.Value == model.Checkpoint) chkBox.SelectedItem = it;
            chkBox.EndUpdate();
            loading = false;
            UpdateChkInfo();
        }
        void UpdateChkInfo()
        {
            var it = chkBox.SelectedItem as NamedItem;
            if (it == null) { chkInfo.Text = ""; return; }
            string c = it.Value;
            var owners = SaveModel.MissionsOfCheckpoint(c);
            bool known = SaveModel.IsKnownCheckpoint(c), story = SaveModel.IsStoryCheckpoint(c);
            string cur = c == model.Checkpoint ? "This is the save's checkpoint. " : "Not applied yet. ";
            chkInfo.ForeColor = !known ? Color.Firebrick : story ? Color.DimGray : Color.DarkGoldenrod;
            chkInfo.Text = cur + (!known ? "The game has no checkpoint with this name and would fall back to its test spot in Madripoor."
                : story ? "Used by " + string.Join(", ", owners) + ". Changing only the checkpoint leaves mission and objective as they are - \"Go there\" keeps all three in step."
                : "Exists in the level but no story objective uses it (test or leftover).");
        }
        void FillGoObjectives(StoryObjective select)
        {
            bool l = loading; loading = true;
            goObjBox.BeginUpdate(); goObjBox.Items.Clear();
            var m = goMissionBox.SelectedItem == null ? null : Story.Mission(((NamedItem)goMissionBox.SelectedItem).Value);
            if (m != null)
            {
                var start = select ?? m.Start;
                foreach (var o in m.Objectives)
                    goObjBox.Items.Add(new NamedItem { Value = o.Name, Label = (o.Index + 1).ToString("00") + "  " + o.Name + (o == m.Start ? "   (mission start)" : "") });
                if (start != null && start.Index < goObjBox.Items.Count) goObjBox.SelectedIndex = start.Index;
            }
            goObjBox.EndUpdate();
            loading = l;
            UpdateGoInfo();
        }
        StoryObjective GoTarget()
        {
            var mi = goMissionBox.SelectedItem as NamedItem; var oi = goObjBox.SelectedItem as NamedItem;
            if (mi == null || oi == null) return null;
            var m = Story.Mission(mi.Value); return m == null ? null : m.Objective(oi.Value);
        }
        void UpdateGoInfo()
        {
            var t = GoTarget();
            if (t == null) { goInfo.Text = ""; return; }
            var st = Story.StatesAt(t); ResolvedState ld, li;
            st.TryGetValue("0x00000000db1c7efe", out ld); st.TryGetValue("0x00000000a3521105", out li);
            int done = Story.Missions.Count(x => Story.IsBefore(x, t.Mission));
            goInfo.Text = "Checkpoint " + Story.CheckpointFor(t) + "   |   loadout " + (ld == null ? "-" : SaveModel.Pretty(ld.State.A).Replace(" Loadout", "")) + "   |   " + (li == null ? "" : li.State.A.Substring(1).ToLowerInvariant() + "   |   ")
                + done + " earlier mission" + (done == 1 ? "" : "s") + " marked complete";
        }
        void GoThere()
        {
            var t = GoTarget(); if (t == null) return;
            try { model.JumpTo(t, resetLaterChk.Checked); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, Text); return; }
            Changed(); FillActivities(); FillTree();
        }
        void RefreshStory()
        {
            if (model == null) return;
            FillCheckpoints();
            loading = true;
            var ms = model.Missions().OrderBy(m => OrderKey(m.Name)).ToList();
            missionGrid.Rows.Clear();
            foreach (var m in ms)
            {
                var sm = Story.Mission(m.Hash);
                int i = missionGrid.Rows.Add(sm == null ? "" : sm.Name == "GP_LOBBY" ? "-" : sm.Index.ToString(), m.Name, sm == null ? m.Region : sm.Region, Fr(m.State), m.Node["CompletedCount"].ToString(), false);
                missionGrid.Rows[i].Tag = m; RefreshMissionRow(missionGrid.Rows[i]);
            }
            objectiveGrid.Rows.Clear();
            foreach (var o in model.Objectives().OrderBy(o => { var so = Story.FindObjective(o.Hash); return so == null ? 999999 : so.Mission.Index * 1000 + so.Index; }))
            {
                var so = Story.FindObjective(o.Hash);
                int i = objectiveGrid.Rows.Add(o.Name, so == null ? "" : so.Checkpoint, Fr(o.State)); objectiveGrid.Rows[i].Tag = o;
                objectiveGrid.Rows[i].DefaultCellStyle.BackColor = o.State == "kComplete" ? Color.FromArgb(232, 245, 233) : o.State == "kActive" ? Color.FromArgb(255, 248, 225) : SystemColors.Window;
            }
            // where the save is now, and the same place preselected in "Go to"
            var pm = Story.Mission(model.PrimaryMission); var po = Story.FindObjective(model.PrimaryObjective);
            nowInfo.Text = (pm == null ? model.NameOf(model.PrimaryMission) : pm.Name) + "  /  " + (po == null ? (model.PrimaryObjective == 0 ? "(no objective)" : model.NameOf(model.PrimaryObjective)) : po.Name) + "     checkpoint " + model.Checkpoint;
            goMissionBox.Items.Clear();
            foreach (var m in Story.Missions) if (m.Name != "GP_LOBBY") goMissionBox.Items.Add(new NamedItem { Value = m.Name, Label = m.Index.ToString("00") + "  " + m.Name + "   (" + m.Region + ")" });
            var selM = po != null ? po.Mission : pm != null && pm.Name != "GP_LOBBY" ? pm : Story.Missions[1];
            foreach (NamedItem it in goMissionBox.Items) if (it.Value == selM.Name) goMissionBox.SelectedItem = it;
            loading = false;
            FillGoObjectives(po != null && po.Mission == selM ? po : null);
            loading = true;
            charBox.Items.Clear();
            var chars = new List<string>(Catalog.Characters);
            if (model.Character != null && !chars.Contains(model.Character)) chars.Insert(0, model.Character);
            foreach (var c in chars) charBox.Items.Add(c);
            charBox.SelectedItem = model.Character; charBox.Enabled = model.Character != null;
            loadoutBox.Items.Clear();
            var lds = new List<string>(Catalog.Loadouts);
            if (model.Loadout != null && !lds.Contains(model.Loadout, StringComparer.OrdinalIgnoreCase)) lds.Insert(0, model.Loadout);
            foreach (var ld in lds) loadoutBox.Items.Add(new NamedItem { Value = ld, Label = SaveModel.Pretty(ld).Replace(" Loadout", "") });
            foreach (NamedItem it in loadoutBox.Items) if (string.Equals(it.Value, model.Loadout, StringComparison.OrdinalIgnoreCase)) loadoutBox.SelectedItem = it;
            loadoutBox.Enabled = model.Loadout != null;
            pctBox.Value = (decimal)Math.Round(Math.Max(0f, Math.Min(1f, model.GamePercent)) * 100f);
            ngpChk.Checked = model.NewGamePlusUnlocked;
            loading = false;
        }
        static string OrderKey(string m)
        {
            int i = Array.IndexOf(Catalog.StoryOrder, m);
            return (i < 0 ? 900 : i).ToString("000") + m;
        }
        void RefreshMissionRow(DataGridViewRow r)
        {
            var m = (MissionInfo)r.Tag;
            bool l = loading; loading = true;
            r.Cells[3].Value = Fr(m.State);
            r.Cells[4].Value = m.Node["CompletedCount"].ToString();
            r.Cells[5].Value = ((List<object>)m.Node["MissionFlagsGame"]).Contains(SaveModel.RewardGiven);
            r.DefaultCellStyle.BackColor = m.State == "kCompleteFinished" ? Color.FromArgb(232, 245, 233) : m.State == "kActive" ? Color.FromArgb(255, 248, 225) : SystemColors.Window;
            loading = l;
        }
        void BulkMissions(string state)
        {
            foreach (DataGridViewRow r in missionGrid.SelectedRows) model.SetMissionState((MissionInfo)r.Tag, state, true);
            Changed();
        }
        void FinishMissionActivities()
        {
            var names = missionGrid.SelectedRows.Cast<DataGridViewRow>().Select(r => ((MissionInfo)r.Tag).Name).ToList();
            int n = model.SetMissionActivities(names, "kFinished");
            Changed(); FillActivities();
            SetStatus(n + " activities marked finished for " + names.Count + " mission" + (names.Count == 1 ? "" : "s") + ".");
        }

        static string ActRegion(ActivityInfo a)
        {
            string id = a.Id ?? "";
            if (id.StartsWith("collectible", StringComparison.OrdinalIgnoreCase)) return "Collectibles";
            string r = SaveModel.RegionOf(id);
            return r == "" || r == "Start" ? "Other" : r;
        }
        void FillActivities()
        {
            if (model == null) return;
            loading = true;
            actGrid.Rows.Clear();
            string f = actFilter.Text.Trim(); string reg = (string)actRegion.SelectedItem;
            var rows = new List<DataGridViewRow>();
            foreach (var a in model.Activities().OrderBy(x => System.Text.RegularExpressions.Regex.IsMatch(x.Id ?? "", "^[0-9a-f]{8}$") ? 1 : 0).ThenBy(x => x.Id))
            {
                string region = ActRegion(a);
                if (reg != "All regions" && region != reg) continue;
                if (f.Length > 0 && (a.Id ?? "").IndexOf(f, StringComparison.OrdinalIgnoreCase) < 0) continue;
                var r = new DataGridViewRow(); r.CreateCells(actGrid, a.Id, region, Fr(a.State), Convert.ToByte(a.Save["Visible"]) != 0); r.Tag = a; rows.Add(r);
            }
            actGrid.Rows.AddRange(rows.ToArray());
            loading = false;
        }
        void BulkActivities(string state)
        {
            foreach (DataGridViewRow r in actGrid.Rows) model.SetActivity((ActivityInfo)r.Tag, state, null);
            Changed(false); FillActivities();
        }

        void FillGear()
        {
            if (model == null) return;
            loading = true;
            FillOwn(partsGrid, "part", Catalog.Parts.Concat(model.Parts().Select(p => p.Path)), true);
            FillOwn(skillsGrid, "skill", Catalog.Skills.Concat(model.Skills().Select(p => p.Path)), false);
            FillOwn(tacticsGrid, "tactic", Catalog.Tactics.Concat(model.Tactics().Select(p => p.Path)), false);
            foreach (DataGridViewRow r in tacticsGrid.Rows)
            {
                var own = model.Tactics().FirstOrDefault(x => string.Equals(x.Path, ((Tuple<string, string>)r.Tag).Item2, StringComparison.OrdinalIgnoreCase));
                r.Cells[tacticsGrid.Columns.Count - 1].Value = own != null && Convert.ToByte(own.Entry["Equipped"]) != 0;
            }
            FillOwn(techGrid, "technique", Catalog.Techniques.Concat(model.Techniques().Select(p => p.Path)), false);
            xpGrid.Rows.Clear();
            foreach (var t in model.LevelTracks())
            {
                string item = t.S("XPItem"); var inv = model.FindItem(item);
                int i = xpGrid.Rows.Add(SaveModel.Pretty(item), inv == null ? "0" : inv["ItemCount"].ToString(), t["RewardedLevelIndex"].ToString(), t["RewardedSkillPoints"].ToString());
                xpGrid.Rows[i].Tag = t;
            }
            loading = false;
            FillSlots2();
        }
        void FillOwn(DataGridView g, string kind, IEnumerable<string> paths, bool cat)
        {
            g.Rows.Clear();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var rows = new List<DataGridViewRow>();
            foreach (var p in paths.Where(x => x != null && seen.Add(x)).OrderBy(x => cat ? SaveModel.PartCategory(x) + SaveModel.Pretty(x) : SaveModel.Pretty(x)))
            {
                var r = new DataGridViewRow();
                string label = SaveModel.Pretty(p) + (Catalog.Unusual.Contains(p, StringComparer.OrdinalIgnoreCase) ? "   (in the files, not in the game's unlock lists)" : "");
                if (cat) r.CreateCells(g, model.Owns(kind, p), label, SaveModel.PartCategory(p), p);
                else if (g == tacticsGrid) r.CreateCells(g, model.Owns(kind, p), label, p, false);
                else r.CreateCells(g, model.Owns(kind, p), label, p);
                r.Tag = Tuple.Create(kind, p); rows.Add(r);
            }
            g.Rows.AddRange(rows.ToArray());
        }
        void FillSlots2()
        {
            slotsPanel.Controls.Clear();
            slotsPanel.Controls.Add(L("Wearing:"));
            foreach (var slot in model.PartSlots())
            {
                string cat = slot.Path.ToLowerInvariant().Contains("claw") ? "Claws" : slot.Path.ToLowerInvariant().Contains("hat") ? "Hat" : "Suit";
                var box = new ComboBox { Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
                var opts = Catalog.Parts.Concat(model.Parts().Select(p => p.Path)).Distinct(StringComparer.OrdinalIgnoreCase)
                    .Where(p => SaveModel.PartCategory(p) == cat).OrderBy(SaveModel.Pretty).ToList();
                string cur = slot.Entry.S("EquippedPartItem");
                if (!opts.Contains(cur, StringComparer.OrdinalIgnoreCase)) opts.Insert(0, cur);
                foreach (var o in opts) box.Items.Add(new NamedItem { Value = o, Label = SaveModel.Pretty(o) + (model.Owns("part", o) ? "" : "  (will be unlocked)") });
                foreach (NamedItem it in box.Items) if (string.Equals(it.Value, cur, StringComparison.OrdinalIgnoreCase)) box.SelectedItem = it;
                var s = slot;
                box.SelectedIndexChanged += (o, e) => { if (box.SelectedItem != null) { model.Equip(s, ((NamedItem)box.SelectedItem).Value); Changed(false); loading = true; FillOwn(partsGrid, "part", Catalog.Parts.Concat(model.Parts().Select(p => p.Path)), true); loading = false; } };
                slotsPanel.Controls.Add(L(cat + ":")); slotsPanel.Controls.Add(box);
            }
        }
        void SetAllOwned(DataGridView g, string kind, bool own)
        {
            foreach (DataGridViewRow r in g.Rows)
            {
                var t = (Tuple<string, string>)r.Tag;
                if (own && Catalog.Unusual.Contains(t.Item2, StringComparer.OrdinalIgnoreCase)) continue;   // unfinished items stay a deliberate, one-by-one choice
                model.SetOwned(t.Item1, t.Item2, own);
            }
            FillGear(); Changed(false);
        }
        void XpChanged(object s, DataGridViewCellEventArgs e)
        {
            if (loading || e.RowIndex < 0) return;
            var t = (Obj)xpGrid.Rows[e.RowIndex].Tag; string v = Convert.ToString(xpGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
            uint n;
            if (!uint.TryParse(v, out n) || n > 99999999) { MessageBox.Show(this, "Enter a whole number from 0 to 99999999."); FillGear(); return; }
            if (e.ColumnIndex == 1) model.SetInventory(t.S("XPItem"), (int)n);
            if (e.ColumnIndex == 2) model.SetFieldLogged(t, "RewardedLevelIndex", n, SaveModel.Pretty(t.S("XPItem")));
            if (e.ColumnIndex == 3) model.SetFieldLogged(t, "RewardedSkillPoints", n, SaveModel.Pretty(t.S("XPItem")));
            Changed(false);
        }

        void FillUnlocks()
        {
            if (model == null) return;
            loading = true;
            nightGrid.Rows.Clear();
            foreach (var c in model.NightmareChallenges())
            {
                var o = c.Value;
                int i = nightGrid.Rows.Add(model.NameOf(c.Key), B(o, "Unlocked"), B(o, "Viewed"), B(o, "Attempted"), B(o, "PrimaryChallengeComplete"), o["BestTier"].ToString());
                nightGrid.Rows[i].Tag = o;
            }
            collGrid.Rows.Clear();
            var rows = new List<DataGridViewRow>();
            foreach (var c in model.Collectibles())
            {
                var r = new DataGridViewRow(); r.CreateCells(collGrid, model.NameOf(c.Item1), model.NameOf(c.Item2), B(c.Item3, "Discovered"), B(c.Item3, "Completed")); r.Tag = c.Item3; rows.Add(r);
            }
            collGrid.Rows.AddRange(rows.ToArray());
            rewardGrid.Rows.Clear();
            foreach (var rw in model.Rewards().OrderBy(x => x.Key))
            {
                if (rw.Value == null || !rw.Value.Has("HasBeenGrantedAtLeastOnce")) continue;
                int i = rewardGrid.Rows.Add(rw.Key, B(rw.Value, "HasBeenGrantedAtLeastOnce")); rewardGrid.Rows[i].Tag = rw.Value;
            }
            galleryGrid.Rows.Clear();
            foreach (var g in model.GalleryEntries())
            {
                int i = galleryGrid.Rows.Add(model.NameOf(Convert.ToUInt32(g["IDHash"])), B(g, "Viewed")); galleryGrid.Rows[i].Tag = g;
            }
            loading = false;
        }
        static bool B(Obj o, string f) { return o.Has(f) && Convert.ToInt64(o[f]) != 0; }
        void GridFieldChanged(DataGridView g, DataGridViewCellEventArgs e, string[] fields, string what)
        {
            if (loading || e.RowIndex < 0 || e.ColumnIndex >= fields.Length || fields[e.ColumnIndex] == null) return;
            var o = (Obj)g.Rows[e.RowIndex].Tag; string fld = fields[e.ColumnIndex];
            object v = g.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            object nv;
            if (v is bool) nv = (bool)v ? 1 : 0;
            else { int n; if (!int.TryParse(Convert.ToString(v), out n)) { FillUnlocks(); return; } nv = n; }
            model.SetFieldLogged(o, fld, nv, what + " " + g.Rows[e.RowIndex].Cells[0].Value);
            if (g == nightGrid) model.SyncNightmareCounts();
            Changed(false);
        }
        void TickColumn(DataGridView g, bool on)
        {
            var cols = g.Columns.Cast<DataGridViewColumn>().Where(c => c is DataGridViewCheckBoxColumn).ToList();
            if (cols.Count == 0) return;
            DataGridViewColumn col = cols[0];
            if (cols.Count > 1)
            {
                using (var f = new Form { Text = "Which column?", Width = 320, Height = 180, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false })
                {
                    var box = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Left = 12, Top = 15, Width = 280 };
                    foreach (var c in cols) box.Items.Add(c.HeaderText); box.SelectedIndex = 0;
                    var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Left = 130, Top = 60, Width = 80 };
                    f.Controls.Add(box); f.Controls.Add(ok); f.AcceptButton = ok;
                    if (f.ShowDialog(this) != DialogResult.OK) return;
                    col = cols[box.SelectedIndex];
                }
            }
            foreach (DataGridViewRow r in g.Rows) r.Cells[col.Index].Value = on;   // fires CellValueChanged per row
            Changed(false);
        }

        void RefreshChanges()
        {
            if (model == null) return;
            changeList.Items.Clear();
            foreach (var c in model.Changes) changeList.Items.Add(c);
            var p = model.Check(game);
            checkBox.Text = p.Count == 0 ? "No problems found: the checkpoint exists and matches the mission in progress, the loadout is one of the game's own, and the install check will not stop this save." : "- " + string.Join(Environment.NewLine + Environment.NewLine + "- ", p);
            checkBox.ForeColor = p.Count == 0 ? Color.DarkGreen : Color.Firebrick;
        }

        // =================================================================================== advanced tree
        class NodeRef { public Obj Owner; public Field Field; public int Index; }
        void FillTree()
        {
            tree.Nodes.Clear();
            foreach (var kv in file.Objects)
            {
                var n = new TreeNode(kv.Key == SaveFile.ROOT ? "Save" : "Section " + kv.Key.ToString("x8")) { Tag = kv.Value };
                n.Nodes.Add("..."); tree.Nodes.Add(n);
            }
        }
        string Label(Field f, int i, object v)
        {
            string name = f.Name;
            if (v is Obj)
            {
                var o = (Obj)v; string sn = o.S("SaveName") ?? o.S("ActivityId") ?? o.S("PartItem") ?? o.S("Item") ?? o.S("TacticItem") ?? o.S("Type");
                uint h; if (sn == null && uint.TryParse(name, out h) && model.Names.ContainsKey(h)) sn = model.Names[h];
                return name + (f.IsArray ? "[" + i + "]" : "") + (sn != null ? "   (" + sn + ")" : "");
            }
            return name + (f.IsArray ? "[" + i + "]" : "") + " = " + Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture);
        }
        void ExpandNode(TreeNode n)
        {
            if (n.Nodes.Count != 1 || n.Nodes[0].Text != "...") return;
            n.Nodes.Clear();
            Obj o = n.Tag as Obj ?? (n.Tag is NodeRef ? ((NodeRef)n.Tag).Field.Values[((NodeRef)n.Tag).Index] as Obj : null);
            if (o == null) return;
            tree.BeginUpdate();
            foreach (var f in o.Fields)
            {
                if (f.IsArray && f.Values.Count == 0) { n.Nodes.Add(new TreeNode(f.Name + " = (empty list)")); continue; }
                for (int i = 0; i < f.Values.Count; i++)
                {
                    var c = new TreeNode(Label(f, i, f.Values[i])) { Tag = new NodeRef { Owner = o, Field = f, Index = i } };
                    if (f.Values[i] is Obj) c.Nodes.Add("...");
                    n.Nodes.Add(c);
                }
            }
            tree.EndUpdate();
        }
        void ShowValue(TreeNode n)
        {
            var r = n.Tag as NodeRef;
            bool scalar = r != null && !(r.Field.Values[r.Index] is Obj);
            valueBox.Enabled = applyValueBtn.Enabled = scalar;
            valueBox.Text = scalar ? Convert.ToString(r.Field.Values[r.Index], System.Globalization.CultureInfo.InvariantCulture) : "";
            valueInfo.Text = scalar ? "type " + r.Field.Type : "";
        }
        void ApplyValue()
        {
            var r = tree.SelectedNode == null ? null : tree.SelectedNode.Tag as NodeRef;
            if (r == null) return;
            object cur = r.Field.Values[r.Index];
            try
            {
                object nv = Convert.ChangeType(valueBox.Text, cur.GetType(), System.Globalization.CultureInfo.InvariantCulture);
                if (Equals(nv, cur)) return;
                r.Field.Values[r.Index] = nv;
                model.Changes.Add("Advanced: " + r.Field.Name + " -> " + valueBox.Text);
                tree.SelectedNode.Text = Label(r.Field, r.Index, nv);
                RefreshAll();
            }
            catch (Exception ex) { MessageBox.Show(this, "Not a valid " + cur.GetType().Name + ": " + ex.Message, Text); }
        }

        /// <summary>For automated checks: pick a mission/objective in "Go to" and press the button.</summary>
        public void TestGo(string mission, string objective)
        {
            foreach (NamedItem it in goMissionBox.Items) if (it.Value == mission) goMissionBox.SelectedItem = it;
            foreach (NamedItem it in goObjBox.Items) if (it.Value == objective) goObjBox.SelectedItem = it;
            GoThere();
        }
        public void TestSave() { DoSave(); }
        /// <summary>Started with --selftest: exercises every tab and, in memory only, a jump to the start of every mission.
        /// Nothing is written to the save.</summary>
        public string SelfTest()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Wolverine Save Editor self-test  " + DateTime.Now);
            sb.AppendLine(".NET runtime " + Environment.Version + ", " + Environment.OSVersion);
            sb.AppendLine("save slots listed: " + slotBox.Items.Count);
            foreach (SlotItem it in slotBox.Items) sb.AppendLine("    " + it.Path);
            sb.AppendLine("game folder: " + (game != null && game.Found ? game.Folder + "  (install check off: " + game.InstallCheckOff + ", forced checkpoint: " + (game.ForcedCheckpoint ?? "none") + ")" : "not found"));
            sb.AppendLine("story data: " + Story.Missions.Count + " missions, " + Story.Missions.Sum(m => m.Objectives.Count) + " objectives, " + Catalog.Checkpoints.Length + " checkpoints");
            if (model == null) { sb.AppendLine("no save open"); sb.AppendLine("RESULT: OK (window and data only)"); return sb.ToString(); }
            sb.AppendLine("open save: " + path);
            sb.AppendLine("    now at " + model.NameOf(model.PrimaryMission) + " / " + model.NameOf(model.PrimaryObjective) + ", checkpoint " + model.Checkpoint);
            byte[] original = File.ReadAllBytes(path);
            bool same = original.SequenceEqual(file.ToBytes());
            sb.AppendLine("    unchanged save writes back identically: " + same);
            foreach (TabPage tp in tabs.TabPages)
            {
                tabs.SelectedTab = tp; Application.DoEvents();
                var inner = tp.Controls.OfType<TabControl>().FirstOrDefault();
                if (inner != null) foreach (TabPage ip in inner.TabPages) { inner.SelectedTab = ip; Application.DoEvents(); }
            }
            tabs.SelectedIndex = 0;
            sb.AppendLine("    tabs shown: " + tabs.TabPages.Count + "; missions listed " + missionGrid.Rows.Count + ", activities " + actGrid.Rows.Count + ", checkpoints in list " + chkBox.Items.Count);
            int ok = 0, bad = 0;
            foreach (var sm in Story.Missions)
            {
                if (sm.Name == "GP_LOBBY" || sm.Start == null) continue;
                try
                {
                    var f = new SaveFile(original); var m = new SaveModel(f);
                    m.JumpTo(sm.Start, true);
                    var back = new SaveModel(new SaveFile(f.ToBytes()));
                    if (back.PrimaryObjective == sm.Start.Hash && SaveModel.IsKnownCheckpoint(back.Checkpoint)) ok++; else { bad++; sb.AppendLine("    jump problem: " + sm.Name); }
                }
                catch (Exception ex) { bad++; sb.AppendLine("    jump error: " + sm.Name + ": " + ex.Message); }
            }
            sb.AppendLine("    in-memory jumps to every mission start: " + ok + " fine, " + bad + " problems");
            sb.AppendLine("    checks for the save as it is: " + (model.Check(game).Count == 0 ? "none" : string.Join(" | ", model.Check(game))));
            sb.AppendLine("    save file on disk untouched: " + original.SequenceEqual(File.ReadAllBytes(path)));
            sb.AppendLine("RESULT: " + (same && bad == 0 ? "OK" : "PROBLEMS"));
            return sb.ToString();
        }
        public void SelectTab(int i) { var parts = i.ToString().ToCharArray(); tabs.SelectedIndex = parts[0] - '0'; if (parts.Length > 1) { var inner = tabs.SelectedTab.Controls.OfType<TabControl>().FirstOrDefault(); if (inner != null) inner.SelectedIndex = parts[1] - '0'; } }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!ConfirmDiscard()) e.Cancel = true;
            base.OnFormClosing(e);
        }
    }

    static class Program
    {
        const string Title = "Wolverine Save Editor";
        static string ErrorFile { get { return Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "WolverineSaveEditor-error.txt"); } }

        static void Report(Exception ex, bool fatal)
        {
            string text = DateTime.Now + "  " + (fatal ? "could not start" : "error") + Environment.NewLine + ex + Environment.NewLine + Environment.NewLine;
            try { File.AppendAllText(ErrorFile, text); } catch { }
            Exception inner = ex; while (inner.InnerException != null) inner = inner.InnerException;
            MessageBox.Show((fatal ? "The editor could not start:\n\n" : "Unexpected error:\n\n") + inner.GetType().Name + ": " + inner.Message +
                "\n\nYour save file was not changed unless you pressed Save.\nDetails were written to " + ErrorFile, Title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Main does nothing but call Run, so that even a failure to load part of the program is caught and shown
        [STAThread]
        static int Main(string[] args)
        {
            try { return Run(args); }
            catch (Exception ex) { Report(ex, true); return 1; }
        }

        static int Run(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Report(e.Exception, false);
            string start = args.FirstOrDefault(a => !a.StartsWith("--"));
            var form = new MainForm(start);
            var tabArg = args.FirstOrDefault(a => a.StartsWith("--tab="));
            var goArg = args.FirstOrDefault(a => a.StartsWith("--go="));
            if (goArg != null) form.Shown += (s, e) => { var p = goArg.Substring(5).Split(new[] { '/' }); form.TestGo(p[0], p.Length > 1 ? p[1] : ""); };
            if (args.Contains("--save")) form.Shown += (s, e) => form.TestSave();
            if (tabArg != null) form.Shown += (s, e) => form.SelectTab(int.Parse(tabArg.Substring(6)));
            if (args.Contains("--selftest"))
                form.Shown += (s, e) =>
                {
                    string report;
                    try { report = form.SelfTest(); } catch (Exception ex) { report = "FAILED" + Environment.NewLine + ex; }
                    try { File.WriteAllText(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "WolverineSaveEditor-selftest.txt"), report); } catch { }
                    form.Close();
                };
            Application.Run(form);
            return 0;
        }
    }
}
