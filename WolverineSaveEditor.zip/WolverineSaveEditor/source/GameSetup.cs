// The game folder's commandline.txt: the two things in it that decide whether an edited save loads as intended.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace WolverineSave
{
    public class GameSetup
    {
        public string Folder;                       // the folder holding commandline.txt, eboot.bin and toc
        public const string InstallFixLine = "{ Engine.PlayGoEnable=false }";
        static readonly Regex PlayGo = new Regex(@"Engine\.PlayGoEnable\s*=\s*(\w+)", RegexOptions.IgnoreCase);
        static readonly Regex Chk = new Regex(@"^\s*-{1,2}checkpoint\s+(\S+)", RegexOptions.IgnoreCase);
        static readonly Regex Start = new Regex(@"^\s*-{1,2}(mission_start|objective_start|mission_available)\b\s*(\S*)", RegexOptions.IgnoreCase);

        public string CommandLinePath { get { return Folder == null ? null : Path.Combine(Folder, "commandline.txt"); } }
        public bool Found { get { return Folder != null && File.Exists(CommandLinePath); } }

        List<string> lines = new List<string>(); string newline = "\r\n"; bool endsWithNewline = true;

        public static bool LooksLikeGame(string folder)
        {
            try { return folder != null && File.Exists(Path.Combine(folder, "commandline.txt")) && (File.Exists(Path.Combine(folder, "eboot.bin")) || File.Exists(Path.Combine(folder, "toc"))); }
            catch { return false; }
        }
        public GameSetup(string folder) { Folder = folder; Reload(); }
        public void Reload()
        {
            lines.Clear();
            if (!Found) return;
            string text = File.ReadAllText(CommandLinePath, Encoding.GetEncoding(28591));
            newline = text.Contains("\r\n") ? "\r\n" : "\n";
            endsWithNewline = text.EndsWith("\n");
            lines = text.Replace("\r\n", "\n").Split('\n').ToList();
            if (endsWithNewline && lines.Count > 0 && lines[lines.Count - 1].Length == 0) lines.RemoveAt(lines.Count - 1);
        }
        public IList<string> Lines { get { return lines.AsReadOnly(); } }

        /// <summary>True when the last PlayGo setting in the file switches the install check off.</summary>
        public bool InstallCheckOff
        {
            get
            {
                bool off = false;
                foreach (var l in lines) { if (l.TrimStart().StartsWith("#") || l.TrimStart().StartsWith("//")) continue; var m = PlayGo.Match(l); if (m.Success) off = m.Groups[1].Value.Equals("false", StringComparison.OrdinalIgnoreCase) || m.Groups[1].Value == "0"; }
                return off;
            }
        }
        public string ForcedCheckpoint
        {
            get { string c = null; foreach (var l in lines) { var m = Chk.Match(l); if (m.Success) c = m.Groups[1].Value; } return c; }
        }
        /// <summary>Other start overrides (-mission_start and friends), as written.</summary>
        public List<string> StartOverrides { get { return lines.Where(l => Start.IsMatch(l)).Select(l => l.Trim()).ToList(); } }

        void Write(string why)
        {
            string p = CommandLinePath;
            string original = p + ".original";
            if (!File.Exists(original)) File.Copy(p, original);
            File.Copy(p, p + ".before-save-editor-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true);
            File.WriteAllText(p, string.Join(newline, lines) + (endsWithNewline ? newline : ""), Encoding.GetEncoding(28591));
            Reload();
        }
        int InsertAt()
        {
            // keep -buildname last, as the game ships it
            for (int i = 0; i < lines.Count; i++) if (lines[i].TrimStart().StartsWith("-buildname", StringComparison.OrdinalIgnoreCase)) return i;
            return lines.Count;
        }
        public void TurnInstallCheckOff()
        {
            if (!Found || InstallCheckOff) return;
            lines.RemoveAll(l => PlayGo.IsMatch(l) && l.Trim().StartsWith("{") && l.Trim().EndsWith("}") && PlayGo.Replace(l, "").Replace("{", "").Replace("}", "").Trim().Length == 0);
            lines.Insert(InsertAt(), InstallFixLine);
            Write("install check off");
        }
        public void RemoveForcedCheckpoint()
        {
            if (!Found || ForcedCheckpoint == null) return;
            lines.RemoveAll(l => Chk.IsMatch(l));
            Write("forced checkpoint removed");
        }

        // ---------------------------------------------------------------- finding the folder
        public static string SettingsFile { get { return Path.Combine(Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath), "WolverineSaveEditor.ini"); } }
        public static string Remembered(string key)
        {
            try { foreach (var l in File.ReadAllLines(SettingsFile)) if (l.StartsWith(key + "=")) return l.Substring(key.Length + 1).Trim(); } catch { }
            return null;
        }
        public static void Remember(string key, string value)
        {
            try
            {
                var all = File.Exists(SettingsFile) ? File.ReadAllLines(SettingsFile).Where(l => !l.StartsWith(key + "=")).ToList() : new List<string>();
                all.Add(key + "=" + value); File.WriteAllLines(SettingsFile, all);
            }
            catch { }
        }
        public static string Find()
        {
            var cands = new List<string>();
            string r = Remembered("game"); if (r != null) cands.Add(r);
            cands.Add(@"C:\wolverine\i38\Wolverine\Wolverine\PPSA03671-app0");
            foreach (var c in cands) if (LooksLikeGame(c)) return c;   // no disk search when a known place works
            try
            {
                foreach (var drive in DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed))
                    foreach (var top in new[] { "wolverine", "Wolverine", "Games", "games" })
                    {
                        string root = Path.Combine(drive.Name, top);
                        if (!Directory.Exists(root)) continue;
                        try { cands.AddRange(Directory.GetDirectories(root, "PPSA03671*", SearchOption.AllDirectories).Take(20)); } catch { }
                    }
            }
            catch { }
            return cands.FirstOrDefault(LooksLikeGame);
        }
    }
}
