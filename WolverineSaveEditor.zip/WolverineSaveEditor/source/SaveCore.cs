// Marvel's Wolverine (PS5, build i38) game.save reader and writer.
// The file is a DAT1 container: header, section table, a table of field names, then serialised
// objects (magic 0x03150044) whose fields are typed values, strings, objects or arrays of them.
// Writing reproduces the original byte for byte when nothing was changed.
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace WolverineSave
{
    public static class Hash
    {
        static readonly uint[] T32 = MakeT32();
        static readonly ulong[] T64 = MakeT64();
        static uint[] MakeT32()
        {
            var t = new uint[256];
            for (uint i = 0; i < 256; i++) { uint c = i; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? (c >> 1) ^ 0xEDB88320u : c >> 1; t[i] = c; }
            return t;
        }
        static ulong[] MakeT64()
        {
            var t = new ulong[256];
            for (ulong i = 0; i < 256; i++) { ulong c = i; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? (c >> 1) ^ 0xC96C5795D7870F42UL : c >> 1; t[i] = c; }
            return t;
        }
        /// <summary>The engine's CRC-32 (init 0xEDB88320, no final xor) used for names and ids.</summary>
        public static uint Crc32(string s) { return Crc32(Encoding.GetEncoding(28591).GetBytes(s)); }
        public static uint Crc32(byte[] b)
        {
            uint c = 0xEDB88320u;
            foreach (byte x in b) c = T32[(c ^ x) & 0xFF] ^ (c >> 8);
            return c;
        }
        /// <summary>Asset id: CRC-64 of the lower-case path, shifted, top bit set.</summary>
        public static ulong AssetId(string s)
        {
            ulong c = 0xC96C5795D7870F42UL;
            foreach (byte x in Encoding.GetEncoding(28591).GetBytes(s.ToLowerInvariant().Replace('\\', '/')))
                c = T64[(c ^ x) & 0xFF] ^ (c >> 8);
            return (c >> 2) | 0x8000000000000000UL;
        }
        internal static ulong StringId(byte[] b)   // as stored before every string value
        {
            ulong c = 0xC96C5795D7870F42UL;
            foreach (byte x0 in b) { byte x = x0; if (x >= 'A' && x <= 'Z') x = (byte)(x + 32); c = T64[(c ^ x) & 0xFF] ^ (c >> 8); }
            return (c >> 2) | 0x8000000000000000UL;
        }
    }

    public enum FType : byte { U8 = 0x00, U16 = 0x01, U32 = 0x02, U64 = 0x03, I8 = 0x04, I16 = 0x05, I32 = 0x06, I64 = 0x07, F32 = 0x08, F64 = 0x09, Str = 0x0a, Obj = 0x0d, Bool = 0x0f }

    public class Field
    {
        public string Name; public FType Type; public bool IsArray; public List<object> Values = new List<object>();
        internal int NameOffset = -1;   // offset of the name inside the name table, kept for byte-exact writes
        public Field(string name, FType type, bool arr) { Name = name; Type = type; IsArray = arr; }
        public object Value { get { return Values.Count > 0 ? Values[0] : null; } set { if (Values.Count == 0) Values.Add(value); else Values[0] = value; } }
        public Field Clone()
        {
            var f = new Field(Name, Type, IsArray); f.NameOffset = NameOffset;
            foreach (var v in Values) f.Values.Add(v is Obj ? ((Obj)v).Clone() : v);
            return f;
        }
    }

    public class Obj
    {
        public List<Field> Fields = new List<Field>();
        public Field F(string name) { foreach (var f in Fields) if (f.Name == name) return f; return null; }
        public bool Has(string name) { return F(name) != null; }
        public object this[string name]
        {
            get { var f = F(name); if (f == null) throw new KeyNotFoundException(name); return f.IsArray ? (object)f.Values : f.Value; }
            set { var f = F(name); if (f == null) throw new KeyNotFoundException(name); f.Value = value; }
        }
        public Obj O(string name) { var f = F(name); return f == null ? null : f.Value as Obj; }
        public string S(string name) { var f = F(name); return f == null ? null : f.Value as string; }
        public Obj Clone() { var o = new Obj(); foreach (var f in Fields) o.Fields.Add(f.Clone()); return o; }
        /// <summary>Follow a path of field names, e.g. "SaveData/Obj/Activities".</summary>
        public Obj Path(string path)
        {
            Obj cur = this;
            foreach (var part in path.Split('/')) { if (cur == null) return null; cur = cur.O(part); }
            return cur;
        }
    }

    public class SaveFile
    {
        const uint OBJ_MAGIC = 0x03150044;
        uint dtype;
        List<uint[]> sections = new List<uint[]>();   // hash, offset, size
        int nameTableStart;
        MemoryStream names = new MemoryStream();
        Dictionary<string, int> nameIndex = new Dictionary<string, int>();
        public Dictionary<uint, Obj> Objects = new Dictionary<uint, Obj>();
        public const uint ROOT = 0x65F6FA6E;
        static readonly Encoding L1 = Encoding.GetEncoding(28591);

        public static SaveFile Load(string path) { return new SaveFile(File.ReadAllBytes(path)); }

        public SaveFile(byte[] b)
        {
            if (b.Length < 16 || BitConverter.ToUInt32(b, 0) != 0x44415431 || BitConverter.ToUInt32(b, 8) != b.Length)
                throw new InvalidDataException("This is not a Wolverine game.save (unexpected header).");
            dtype = BitConverter.ToUInt32(b, 4);
            int n = BitConverter.ToInt32(b, 12);
            int first = int.MaxValue;
            for (int i = 0; i < n; i++)
            {
                var s = new uint[] { BitConverter.ToUInt32(b, 16 + 12 * i), BitConverter.ToUInt32(b, 20 + 12 * i), BitConverter.ToUInt32(b, 24 + 12 * i) };
                sections.Add(s); first = Math.Min(first, (int)s[1]);
            }
            nameTableStart = 16 + 12 * n;
            names.Write(b, nameTableStart, first - nameTableStart);
            foreach (var s in sections)
            {
                int end;
                var o = ReadObj(b, (int)s[1], out end);
                if (end != s[1] + s[2]) throw new InvalidDataException("Section size mismatch.");
                Objects[s[0]] = o;
            }
        }

        public Obj Root { get { return Objects[ROOT]; } }

        static int Al4(int p) { return (p + 3) & ~3; }

        Obj ReadObj(byte[] b, int o, out int end)
        {
            if (BitConverter.ToUInt32(b, o) != 0 || BitConverter.ToUInt32(b, o + 4) != OBJ_MAGIC) throw new InvalidDataException("Bad object at " + o);
            int n = BitConverter.ToInt32(b, o + 8); int size = BitConverter.ToInt32(b, o + 12);
            end = o + 16 + size; int p = o + 16;
            var hashes = new uint[n]; var types = new uint[n]; var noffs = new int[n];
            for (int i = 0; i < n; i++) { hashes[i] = BitConverter.ToUInt32(b, p); types[i] = BitConverter.ToUInt32(b, p + 4); p += 8; }
            for (int i = 0; i < n; i++) { noffs[i] = BitConverter.ToInt32(b, p); p += 4; }
            p = Al4(p);
            var ob = new Obj();
            for (int i = 0; i < n; i++)
            {
                int no = noffs[i]; int e = no; while (b[e] != 0) e++;
                string name = L1.GetString(b, no, e - no);
                if (Hash.Crc32(name) != hashes[i]) throw new InvalidDataException("Field name check failed: " + name);
                uint t = types[i]; var ty = (FType)(t >> 24); int cnt = (int)((t >> 4) & 0xFFFFF); bool arr = (t & 0xF) != 0;
                var f = new Field(name, ty, arr); f.NameOffset = no - nameTableStart;
                if (!nameIndex.ContainsKey(name)) nameIndex[name] = f.NameOffset;
                if (arr && cnt == 0) p += 1;
                for (int k = 0; k < cnt; k++)
                {
                    switch (ty)
                    {
                        case FType.Obj: { int pe; f.Values.Add(ReadObj(b, p, out pe)); p = pe; break; }
                        case FType.Str: { int ln = BitConverter.ToInt32(b, p); f.Values.Add(L1.GetString(b, p + 16, ln)); p += 16 + Al4(ln + 1); break; }
                        case FType.U8: f.Values.Add(b[p]); p += 1; break;
                        case FType.Bool: f.Values.Add(b[p]); p += 1; break;
                        case FType.I8: f.Values.Add((sbyte)b[p]); p += 1; break;
                        case FType.U16: f.Values.Add(BitConverter.ToUInt16(b, p)); p += 2; break;
                        case FType.I16: f.Values.Add(BitConverter.ToInt16(b, p)); p += 2; break;
                        case FType.U32: f.Values.Add(BitConverter.ToUInt32(b, p)); p += 4; break;
                        case FType.I32: f.Values.Add(BitConverter.ToInt32(b, p)); p += 4; break;
                        case FType.U64: f.Values.Add(BitConverter.ToUInt64(b, p)); p += 8; break;
                        case FType.I64: f.Values.Add(BitConverter.ToInt64(b, p)); p += 8; break;
                        case FType.F32: f.Values.Add(BitConverter.ToSingle(b, p)); p += 4; break;
                        case FType.F64: f.Values.Add(BitConverter.ToDouble(b, p)); p += 8; break;
                        default: throw new InvalidDataException("Unknown field type " + (int)ty + " in " + name);
                    }
                }
                ob.Fields.Add(f);
            }
            if (p > end) throw new InvalidDataException("Object overruns its size.");
            return ob;
        }

        // ----------------------------------------------------------------------------- writing
        bool NameAt(int off, string name)
        {
            var nb = L1.GetBytes(name); var buf = names.GetBuffer(); int len = (int)names.Length;
            if (off < 0 || off + nb.Length >= len) return false;
            for (int i = 0; i < nb.Length; i++) if (buf[off + i] != nb[i]) return false;
            return buf[off + nb.Length] == 0;
        }
        int NameOffset(Field f)
        {
            if (f.NameOffset >= 0 && NameAt(f.NameOffset, f.Name)) return f.NameOffset;
            int off;
            if (nameIndex.TryGetValue(f.Name, out off) && NameAt(off, f.Name)) { f.NameOffset = off; return off; }
            off = (int)names.Length; var nb = L1.GetBytes(f.Name);
            names.Write(nb, 0, nb.Length); names.WriteByte(0);
            nameIndex[f.Name] = off; f.NameOffset = off;
            return off;
        }

        void WriteObj(Obj ob, MemoryStream w, long start, int nameBase)
        {
            long at = w.Position;   // == start
            var bw = new BinaryWriter(w);
            int n = ob.Fields.Count;
            bw.Write(0u); bw.Write(OBJ_MAGIC); bw.Write(n); bw.Write(0);
            var offs = new int[n];
            for (int i = 0; i < n; i++)
            {
                var f = ob.Fields[i];
                if (!f.IsArray && f.Values.Count != 1) throw new InvalidOperationException("Field " + f.Name + " needs exactly one value.");
                bw.Write(Hash.Crc32(f.Name));
                bw.Write(((uint)f.Type << 24) | ((uint)f.Values.Count << 4) | (f.IsArray ? 1u : 0u));
                offs[i] = NameOffset(f);
            }
            for (int i = 0; i < n; i++) bw.Write(nameBase + offs[i]);
            while (w.Position % 4 != 0) w.WriteByte(0);
            foreach (var f in ob.Fields)
            {
                if (f.IsArray && f.Values.Count == 0) { w.WriteByte(0); continue; }
                foreach (var v in f.Values)
                {
                    switch (f.Type)
                    {
                        case FType.Obj: WriteObj((Obj)v, w, w.Position, nameBase); break;
                        case FType.Str:
                            {
                                var sb = L1.GetBytes((string)v); int ln = sb.Length;
                                bw.Write(ln); bw.Write(ln > 0 ? Hash.Crc32(sb) : 0u); bw.Write(ln > 0 ? Hash.StringId(sb) : 0UL);
                                w.Write(sb, 0, ln); int pad = Al4(ln + 1) - ln; for (int k = 0; k < pad; k++) w.WriteByte(0);
                                break;
                            }
                        case FType.U8: case FType.Bool: w.WriteByte(Convert.ToByte(v)); break;
                        case FType.I8: w.WriteByte(unchecked((byte)Convert.ToSByte(v))); break;
                        case FType.U16: bw.Write(Convert.ToUInt16(v)); break;
                        case FType.I16: bw.Write(Convert.ToInt16(v)); break;
                        case FType.U32: bw.Write(Convert.ToUInt32(v)); break;
                        case FType.I32: bw.Write(Convert.ToInt32(v)); break;
                        case FType.U64: bw.Write(Convert.ToUInt64(v)); break;
                        case FType.I64: bw.Write(Convert.ToInt64(v)); break;
                        case FType.F32: bw.Write(Convert.ToSingle(v)); break;
                        case FType.F64: bw.Write(Convert.ToDouble(v)); break;
                    }
                }
            }
            while (w.Position % 4 != 0) w.WriteByte(0);
            long endPos = w.Position;
            w.Position = at + 12; bw.Write((int)(endPos - at - 16)); w.Position = endPos;
        }

        public byte[] ToBytes()
        {
            // Serialise once to discover any new names, then lay the file out for real.
            int n = sections.Count;
            var order = new List<uint[]>(sections); order.Sort((a, c) => a[1].CompareTo(c[1]));
            for (int pass = 0; pass < 2; pass++)
            {
                long namesLen = names.Length;
                var outp = new MemoryStream();
                var bw = new BinaryWriter(outp);
                bw.Write(0x44415431u); bw.Write(dtype); bw.Write(0); bw.Write(n);
                for (int i = 0; i < n; i++) { bw.Write(0u); bw.Write(0u); bw.Write(0u); }
                outp.Write(names.GetBuffer(), 0, (int)names.Length);
                while (outp.Position % 16 != 0) outp.WriteByte(0);
                var placed = new Dictionary<uint, long[]>();
                foreach (var s in order)
                {
                    while (outp.Position % 16 != 0) outp.WriteByte(0);
                    long st = outp.Position;
                    WriteObj(Objects[s[0]], outp, st, nameTableStart);
                    placed[s[0]] = new long[] { st, outp.Position - st };
                }
                if (names.Length != namesLen) continue;   // names were added: lay out again
                for (int i = 0; i < n; i++)
                {
                    outp.Position = 16 + 12 * i; bw.Write(sections[i][0]); bw.Write((uint)placed[sections[i][0]][0]); bw.Write((uint)placed[sections[i][0]][1]);
                }
                outp.Position = 8; bw.Write((uint)outp.Length);
                return outp.ToArray();
            }
            throw new InvalidOperationException("Could not lay out the save.");
        }
    }
}
