// The game's story as the game files describe it: missions in order, every objective with its checkpoint,
// and the world/loadout/lighting states each one sets. Parsed from the table in StoryData.cs.
using System;
using System.Collections.Generic;
using System.Linq;

namespace WolverineSave
{
    /// <summary>One state a mission or objective sets when it starts. Kind: W world state (A = enum asset, B = value),
    /// L mission loadout, G new-game-plus loadout, C character, N lighting mode (value in A).</summary>
    public class StoryState { public char Kind; public string A, B; }

    public class StoryObjective
    {
        public string Name, Checkpoint; public int Index; public int[] Next = new int[0];
        public List<StoryState> States = new List<StoryState>(); public StoryMission Mission; public uint Hash;
        public override string ToString() { return Name; }
    }
    public class StoryMission
    {
        public string Name, Available, Graph, Act, Location, StartCheckpoint, StartObjective; public bool Hub; public int Index;
        public List<StoryState> States = new List<StoryState>(); public List<StoryObjective> Objectives = new List<StoryObjective>();
        public uint Hash; public ulong GraphId;
        public string GraphKey { get { return "0x" + GraphId.ToString("x16"); } }
        public StoryObjective Objective(string name) { return Objectives.FirstOrDefault(o => o.Name == name); }
        public StoryObjective Start { get { return Objective(StartObjective) ?? Objectives.FirstOrDefault(); } }
        /// <summary>Objectives that have to be finished before the given one can be reached.</summary>
        public HashSet<int> Before(int objective)
        {
            var prev = new List<int>[Objectives.Count];
            for (int i = 0; i < prev.Length; i++) prev[i] = new List<int>();
            foreach (var o in Objectives) foreach (int n in o.Next) if (n >= 0 && n < prev.Length) prev[n].Add(o.Index);
            var seen = new HashSet<int>(); var todo = new Stack<int>(); todo.Push(objective);
            while (todo.Count > 0) foreach (int p in prev[todo.Pop()]) if (p != objective && seen.Add(p)) todo.Push(p);
            return seen;
        }
        public string Region
        {
            get
            {
                if (Name.Contains("_TEL_")) return "Telambang"; if (Name.Contains("_CAN_")) return "Canada";
                if (Name.Contains("_JPN_")) return "Japan"; if (Name.Contains("_MAD_")) return "Madripoor";
                if (Name == "GP_LOBBY") return "Menu"; return "Post-game";
            }
        }
        public override string ToString() { return Name; }
    }
    public class ActivityLink { public string Id, Objective; public string[] Missions; }

    /// <summary>A state as it should stand in the save, with the mission or objective that set it.</summary>
    public class ResolvedState { public StoryState State; public string Source; public uint MissionHash; }

    public static partial class Story
    {
        public static readonly List<StoryMission> Missions = new List<StoryMission>();
        public static readonly List<StoryState> Defaults = new List<StoryState>();
        public static readonly List<ActivityLink> Activities = new List<ActivityLink>();
        public static readonly Dictionary<string, List<StoryObjective>> ByCheckpoint = new Dictionary<string, List<StoryObjective>>();
        /// <summary>Last objective that is part of the first install chunk; past it the game wants the whole game installed.</summary>
        public static string InstallMission, InstallObjective;
        public const string ActAsset = "enums/MissionActs.dynamicenum";

        static Story()
        {
            StoryMission m = null; StoryObjective o = null;
            foreach (var raw in Data.Split('\n'))
            {
                var line = raw.TrimEnd('\r'); if (line.Length == 0) continue;
                var p = line.Split('\t');
                switch (p[0])
                {
                    case "D": Defaults.Add(St(p)); break;
                    case "M":
                        m = new StoryMission { Name = p[1], Available = p[2], Graph = p[3], Act = p[4], Location = p[5], StartCheckpoint = p[6], StartObjective = p[7], Hub = p[8] == "1", Index = Missions.Count };
                        m.Hash = Hash.Crc32(m.Name); m.GraphId = m.Graph.Length > 0 ? Hash.AssetId(m.Graph) : 0; Missions.Add(m); o = null; break;
                    case "S": m.States.Add(St(p)); break;
                    case "O":
                        o = new StoryObjective { Name = p[1], Checkpoint = p[2], Mission = m, Index = m.Objectives.Count, Hash = Hash.Crc32(p[1]) };
                        if (p.Length > 3 && p[3].Length > 0) o.Next = p[3].Split(',').Select(int.Parse).ToArray();
                        m.Objectives.Add(o);
                        if (o.Checkpoint.Length > 0) { List<StoryObjective> l; if (!ByCheckpoint.TryGetValue(o.Checkpoint, out l)) ByCheckpoint[o.Checkpoint] = l = new List<StoryObjective>(); l.Add(o); }
                        break;
                    case "s": o.States.Add(St(p)); break;
                    case "A": Activities.Add(new ActivityLink { Id = p[1], Missions = p[2].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries), Objective = p.Length > 3 ? p[3] : "" }); break;
                    case "I": InstallMission = p[1]; InstallObjective = p[2]; break;
                }
            }
        }
        static StoryState St(string[] p) { return new StoryState { Kind = p[1][0], A = p[2], B = p.Length > 3 ? p[3] : "" }; }

        public static StoryMission Mission(string name) { return Missions.FirstOrDefault(x => x.Name == name); }
        public static StoryMission Mission(uint hash) { return Missions.FirstOrDefault(x => x.Hash == hash); }
        public static StoryObjective FindObjective(uint hash)
        {
            foreach (var m in Missions) foreach (var o in m.Objectives) if (o.Hash == hash) return o;
            return null;
        }
        /// <summary>The checkpoint to start an objective from.</summary>
        public static string CheckpointFor(StoryObjective o)
        {
            if (o.Checkpoint.Length > 0) return o.Checkpoint;
            if (o.Mission.StartObjective == o.Name && o.Mission.StartCheckpoint.Length > 0) return o.Mission.StartCheckpoint;
            for (int i = o.Index - 1; i >= 0; i--) if (o.Mission.Objectives[i].Checkpoint.Length > 0) return o.Mission.Objectives[i].Checkpoint;
            return o.Mission.StartCheckpoint.Length > 0 ? o.Mission.StartCheckpoint : o.Mission.Available;
        }
        /// <summary>Missions that are finished by the time the given one starts (hubs and the menu are not story steps).</summary>
        public static bool IsBefore(StoryMission a, StoryMission target)
        {
            if (a == target || a.Hub || a.Name == "GP_LOBBY") return false;
            // the two post-game missions sit side by side after the epilogue
            if (a.Act == "kPostGP" && target.Act == "kPostGP") return false;
            return a.Index < target.Index;
        }
        public static string StateKey(StoryState s)
        {
            switch (s.Kind)
            {
                case 'W': return "0x" + Hash.AssetId(s.A).ToString("x16");
                case 'N': return "0x00000000a3521105";
                case 'C': return "0x000000005e515c84";
                case 'L': return "0x00000000db1c7efe";
                case 'G': return "0x00000000ff218960";
            }
            return null;
        }
        /// <summary>Replays every state the story sets up to and including the given objective, the way the game does when
        /// it starts a mission directly: defaults, then each earlier mission and its objectives in order, then this one.</summary>
        public static Dictionary<string, ResolvedState> StatesAt(StoryObjective target, bool includeOwnMission = true)
        {
            var d = new Dictionary<string, ResolvedState>();
            Action<StoryState, string, uint> put = (s, src, mh) => d[StateKey(s)] = new ResolvedState { State = s, Source = src, MissionHash = mh };
            foreach (var s in Defaults) put(s, "Mission Graph Init Node", 0);
            var lobby = Mission("GP_LOBBY");
            string act = "kAct1";
            Action<StoryMission, HashSet<int>> run = (m, only) =>
            {
                if (m.Act != act) { act = m.Act; put(new StoryState { Kind = 'W', A = ActAsset, B = act }, "Act Change Node", 0); }
                foreach (var s in m.States) put(s, m.Name, m.Hash);
                foreach (var o in m.Objectives) if (only == null || only.Contains(o.Index)) foreach (var s in o.States) put(s, o.Name, 0);
            };
            if (lobby != null) run(lobby, null);
            foreach (var m in Missions) if (IsBefore(m, target.Mission)) run(m, null);
            if (target.Mission != lobby && includeOwnMission)
            {
                var only = target.Mission.Before(target.Index); only.Add(target.Index);
                run(target.Mission, only);
            }
            return d;
        }
    }
}
